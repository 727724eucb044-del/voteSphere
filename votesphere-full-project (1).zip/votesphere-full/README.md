# VoteSphere — Full Stack Project

Election campaign management platform. This repo contains both the Spring Boot backend and the React frontend, wired together and ready to run.

```
votesphere-full/
├── backend/     # Spring Boot 3.2.5, Java 17, JWT auth, MySQL/JPA
└── frontend/    # React 19 + Redux Toolkit
```

## How the two sides connect

- Backend runs on **http://localhost:8080**, all endpoints under `/api/**` (e.g. `/api/auth`, `/api/voters`, `/api/shifts`, `/api/events`, `/api/interactions`).
- Frontend reads the API base URL from `frontend/.env`:
  ```
  REACT_APP_API_BASE_URL=http://localhost:8080/api
  ```
- Backend CORS (`SecurityConfig.java`) allows all origins, so the React dev server (port 3000) can call it without extra config.

If you deploy the backend somewhere other than `localhost:8080`, just update `frontend/.env` to match — nothing else needs to change.

## 1. Run the backend

**Prerequisites:** Java 17, Maven (or use the included `mvnw` wrapper), MySQL running locally.

1. Create the database:
   ```sql
   CREATE DATABASE backend_db;
   ```
2. Check `backend/src/main/resources/application.properties` — update the MySQL username/password if yours differ from the defaults (`root` / `1234`):
   ```
   spring.datasource.url=jdbc:mysql://localhost:3306/backend_db
   spring.datasource.username=root
   spring.datasource.password=1234
   ```
3. Start the backend:
   ```bash
   cd backend
   ./mvnw spring-boot-run   # or: ./mvnw spring-boot:run
   ```
   The API will be available at `http://localhost:8080`. `DataSeeder` creates a default admin account on first run — check `DataSeeder.java` for the seeded credentials.

## 2. Run the frontend

**Prerequisites:** Node.js 18+.

```bash
cd frontend
npm install
npm start
```

This starts the React dev server at `http://localhost:3000`, which will call the backend at the URL configured in `.env`.

## 3. Use the app

- Open `http://localhost:3000`.
- Log in with the seeded admin credentials (see `backend/src/main/java/com/example/demo/config/DataSeeder.java`) or register a new account.
- Navigate voter profiles, volunteer shifts, outreach events, campaign staff, and voter interactions from the dashboard.

## Notes

- JWT secret and DB credentials in `application.properties` are dev defaults — replace them before any real deployment.
- To build a production frontend bundle: `npm run build` inside `frontend/`.
- To package the backend as a runnable jar: `./mvnw clean package` inside `backend/`, then `java -jar target/*.jar`.
