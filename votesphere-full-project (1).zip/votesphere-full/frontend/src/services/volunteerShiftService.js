import axiosInstance from "../api/axiosInstance";

export const getAllShifts = async () => {
  const response = await axiosInstance.get("/shifts");
  return response.data;
};

export const createShift = async (dto) => {
  const response = await axiosInstance.post("/shifts", dto);
  return response.data;
};

export const reserveShift = async (shiftId, accountId) => {
  const response = await axiosInstance.post(`/shifts/${shiftId}/reserve`, null, {
    params: { accountId },
  });
  return response.data;
};

export const updateShiftStatus = async (id, status) => {
  const response = await axiosInstance.put(`/shifts/${id}/status`, null, {
    params: { status },
  });
  return response.data;
};

export const getMySchedule = async (accountId) => {
  const response = await axiosInstance.get("/shifts/my-schedule", {
    params: { accountId },
  });
  return response.data;
};

export const deleteShift = async (id) => {
  const response = await axiosInstance.delete(`/shifts/${id}`);
  return response.data;
};

const volunteerShiftService = {
  getAllShifts,
  createShift,
  reserveShift,
  updateShiftStatus,
  getMySchedule,
  deleteShift,
};

export default volunteerShiftService;
