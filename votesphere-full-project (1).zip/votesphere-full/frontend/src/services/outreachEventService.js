import axiosInstance from "../api/axiosInstance";

export const getAllEvents = async () => {
  const response = await axiosInstance.get("/events");
  return response.data;
};

export const getEventById = async (id) => {
  const response = await axiosInstance.get(`/events/${id}`);
  return response.data;
};

export const createEvent = async (dto) => {
  const response = await axiosInstance.post("/events", dto);
  return response.data;
};

export const updateEvent = async (id, dto) => {
  const response = await axiosInstance.put(`/events/${id}`, dto);
  return response.data;
};

export const deleteEvent = async (id) => {
  const response = await axiosInstance.delete(`/events/${id}`);
  return response.data;
};

export const concludeEvent = async (id) => {
  const response = await axiosInstance.post(`/events/${id}/conclude`);
  return response.data;
};

const outreachEventService = {
  getAllEvents,
  getEventById,
  createEvent,
  updateEvent,
  deleteEvent,
  concludeEvent,
};

export default outreachEventService;
