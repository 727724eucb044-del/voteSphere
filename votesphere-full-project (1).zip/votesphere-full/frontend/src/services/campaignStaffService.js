import axiosInstance from "../api/axiosInstance";

// NOTE: The backend does not currently expose a staff-directory controller
// (no /api/staff endpoint exists in the provided backend). This service calls
// the conventional REST path so the Staff Management screen is wired and
// ready the moment that endpoint is added server-side; until then the UI
// surfaces the resulting error via NotificationStack instead of crashing.
export const getAllStaff = async () => {
  const response = await axiosInstance.get("/staff");
  return response.data;
};

const campaignStaffService = { getAllStaff };

export default campaignStaffService;
