import axiosInstance from "../api/axiosInstance";

export const login = async (credentials) => {
  const response = await axiosInstance.post("/auth/login", credentials);
  return response.data;
};

export const register = async (registrationData) => {
  const response = await axiosInstance.post("/auth/register", registrationData);
  return response.data;
};

// Bundled default export alongside the standard named exports above.
const authService = { login, register };

export default authService;
