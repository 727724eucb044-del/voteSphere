import axiosInstance from "../api/axiosInstance";

export const getAllInteractions = async () => {
  const response = await axiosInstance.get("/interactions");
  return response.data;
};

export const logInteraction = async (dto) => {
  const response = await axiosInstance.post("/interactions/log", dto);
  return response.data;
};

export const getRecentFeed = async () => {
  const response = await axiosInstance.get("/interactions/recent-feed");
  return response.data;
};

const voterInteractionService = { getAllInteractions, logInteraction, getRecentFeed };

export default voterInteractionService;
