import axiosInstance from "../api/axiosInstance";

export const getAllVoters = async () => {
  const response = await axiosInstance.get("/voters");
  return response.data;
};

export const getVoterById = async (id) => {
  const response = await axiosInstance.get(`/voters/${id}`);
  return response.data;
};

export const createVoter = async (dto) => {
  const response = await axiosInstance.post("/voters", dto);
  return response.data;
};

export const updateVoter = async (id, dto) => {
  const response = await axiosInstance.put(`/voters/${id}`, dto);
  return response.data;
};

export const deleteVoter = async (id) => {
  const response = await axiosInstance.delete(`/voters/${id}`);
  return response.data;
};

export const getDistrictMetrics = async (district) => {
  const response = await axiosInstance.get("/voters/district-metrics", {
    params: { district },
  });
  return response.data;
};

const voterProfileService = {
  getAllVoters,
  getVoterById,
  createVoter,
  updateVoter,
  deleteVoter,
  getDistrictMetrics,
};

export default voterProfileService;
