import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { logout } from "../../store/slices/authSlice";

const Navbar = () => {
  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { role, token } = useSelector((state) => state.auth);

  const handleLogout = () => {
    dispatch(logout());
    navigate("/login");
  };

  const renderLinks = () => {
    if (!token) {
      return (
        <>
          <Link to="/login">Sign In</Link>
          <Link to="/register">Register Account</Link>
        </>
      );
    }

    switch (role) {
      case "CAMPAIGN_DIRECTOR":
        return (
          <>
            <Link to="/events">Outreach Events</Link>
            <Link to="/voters">Voter Registry</Link>
            <Link to="/staff">Staff Management</Link>
          </>
        );
      case "OUTREACH_VOLUNTEER":
        return (
          <>
            <Link to="/shifts">My Shifts</Link>
            <Link to="/interactions">Engagement Logs</Link>
          </>
        );
      case "FIELD_ORGANIZER":
        return (
          <>
            <Link to="/events">Outreach Events</Link>
            <Link to="/voters">Voter Registry</Link>
            <Link to="/shifts">Shift Schedule</Link>
            <Link to="/interactions">Engagement Logs</Link>
          </>
        );
      case "COMPLIANCE_AUDITOR":
        return (
          <>
            <Link to="/events">Outreach Events</Link>
            <Link to="/interactions">Engagement Logs</Link>
          </>
        );
      default:
        return null;
    }
  };

  return (
    <nav className="navbar">
      <Link to="/" className="navbar-brand">
        VoteSphere
      </Link>
      <div className="navbar-links">{renderLinks()}</div>
      {token && (
        <button type="button" className="logout-btn" onClick={handleLogout}>
          Logout
        </button>
      )}
    </nav>
  );
};

export default Navbar;
