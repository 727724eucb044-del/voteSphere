import React from "react";

const NotificationStack = ({ notifications, removeNotification }) => {
  // Defensive: never assume notifications is a populated array.
  const list = notifications && notifications.length ? notifications : [];

  if (!list.length) return null;

  return (
    <div className="notification-stack">
      {list.map((notification) => (
        <div
          key={notification.id}
          className={`notification notification-${notification.type || "info"}`}
        >
          <span>{notification.message}</span>
          <button
            type="button"
            className="notification-dismiss"
            onClick={() => removeNotification && removeNotification(notification.id)}
            aria-label="Dismiss notification"
          >
            ×
          </button>
        </div>
      ))}
    </div>
  );
};

export default NotificationStack;
