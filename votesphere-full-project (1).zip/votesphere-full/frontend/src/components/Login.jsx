import React, { useEffect, useState } from "react";
import { useNavigate, Link, useLocation } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import { loginUser, registerUser, resetAuthStatus } from "../store/slices/authSlice";

const ROLE_OPTIONS = [
  "CAMPAIGN_DIRECTOR",
  "FIELD_ORGANIZER",
  "OUTREACH_VOLUNTEER",
  "COMPLIANCE_AUDITOR",
];

const Login = () => {
  const location = useLocation();
  const isRegisterRoute = location.pathname.startsWith("/register");
  const [mode, setMode] = useState(isRegisterRoute ? "register" : "login");

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  const [domainRole, setDomainRole] = useState(ROLE_OPTIONS[0]);
  const [phoneNumber, setPhoneNumber] = useState("");

  const dispatch = useDispatch();
  const navigate = useNavigate();
  const { isloading, iserror, message, token } = useSelector((state) => state.auth);

  useEffect(() => {
    setMode(isRegisterRoute ? "register" : "login");
  }, [isRegisterRoute]);

  useEffect(() => {
    dispatch(resetAuthStatus());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode]);

  useEffect(() => {
    if (iserror && message) {
      alert(message);
    }
  }, [iserror, message]);

  useEffect(() => {
    if (token) {
      navigate("/");
    }
  }, [token, navigate]);

  const handleSubmit = (e) => {
    e.preventDefault();
    if (mode === "login") {
      dispatch(loginUser({ email, password }));
    } else {
      dispatch(
        registerUser({
          email,
          password,
          fullName,
          domainRole,
          phoneNumber,
        })
      );
    }
  };

  const isRegister = mode === "register";
  const requiredFieldsFilled = isRegister
    ? email && password && fullName && domainRole
    : email && password;

  return (
    <div className="auth-page">
      <form className="auth-form" onSubmit={handleSubmit}>
        <h2>{isRegister ? "Create Access Key" : "Sign In"}</h2>

        <div className="form-field">
          <label htmlFor="email">Email Address *</label>
          <input
            id="email"
            name="email"
            type="email"
            placeholder="director@votesphere.org"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>

        <div className="form-field">
          <label htmlFor="password">Password{isRegister ? " *" : ""}</label>
          <input
            id="password"
            name="password"
            type="password"
            placeholder="Enter secure password string"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>

        {isRegister && (
          <>
            <div className="form-field">
              <label htmlFor="fullName">Full Name *</label>
              <input
                id="fullName"
                name="fullName"
                type="text"
                placeholder="e.g. Marcus Cole"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                required
              />
            </div>

            <div className="form-field">
              <label htmlFor="domainRole">Operational Framework Role *</label>
              <select
                id="domainRole"
                name="domainRole"
                value={domainRole}
                onChange={(e) => setDomainRole(e.target.value)}
                required
              >
                {ROLE_OPTIONS.map((role) => (
                  <option key={role} value={role}>
                    {role.replace(/_/g, " ")}
                  </option>
                ))}
              </select>
            </div>

            <div className="form-field">
              <label htmlFor="phoneNumber">Secure Contact Number</label>
              <input
                id="phoneNumber"
                name="phoneNumber"
                type="tel"
                value={phoneNumber}
                onChange={(e) => setPhoneNumber(e.target.value)}
              />
            </div>
          </>
        )}

        <button
          type="submit"
          className="submit-btn"
          disabled={isloading || !requiredFieldsFilled}
        >
          {isloading ? "Processing Credentials..." : isRegister ? "Create Access Key" : "Sign In"}
        </button>

        <div className="auth-switch">
          {isRegister ? (
            <span>
              Already have an account? <Link to="/login">Sign In</Link>
            </span>
          ) : (
            <span>
              Need access? <Link to="/register">Register Account</Link>
            </span>
          )}
        </div>
      </form>
    </div>
  );
};

export default Login;
