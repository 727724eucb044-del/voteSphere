import React from "react";

const STATUS_COLORS = {
  PLANNED: "#5b7fd6",
  ACTIVE: "#3f9f5f",
  COMPLETED: "#6c757d",
  CANCELLED: "#d9364f",
  OPEN: "#5b7fd6",
  RESERVED: "#e8a53d",
  MISSED: "#d9364f",
  UNCONTACTED: "#6c757d",
  CONTACTED: "#3f9f5f",
  FOLLOW_UP_REQUIRED: "#e8a53d",
};

const capitalize = (text) => {
  if (!text) return "";
  return text
    .toLowerCase()
    .split("_")
    .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
    .join(" ");
};

const StatusBadge = ({ status }) => {
  const backgroundColor = STATUS_COLORS[status] || "#8a8a8a";

  return (
    <span className="status-badge" style={{ backgroundColor }}>
      {capitalize(status)}
    </span>
  );
};

export default StatusBadge;
