import React from "react";

const LoadingSpinner = () => {
  return (
    <div className="loading-spinner-wrapper">
      <div className="loading-spinner" />
      <span>Synchronizing domain data...</span>
    </div>
  );
};

export default LoadingSpinner;
