import React from "react";

const EmptyState = ({ message }) => {
  return <div className="empty-state">{message}</div>;
};

export default EmptyState;
