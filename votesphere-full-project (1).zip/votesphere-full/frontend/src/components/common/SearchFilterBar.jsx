import React from "react";

const STATUS_OPTIONS = ["ALL", "PLANNED", "ACTIVE", "COMPLETED", "CANCELLED"];

const SearchFilterBar = ({
  searchValue,
  onSearchChange,
  statusValue,
  onStatusChange,
  statusOptions = STATUS_OPTIONS,
  searchPlaceholder = "Search...",
}) => {
  return (
    <div className="search-filter-bar">
      <input
        type="text"
        className="search-input"
        placeholder={searchPlaceholder}
        value={searchValue}
        onChange={(e) => onSearchChange(e.target.value)}
      />
      <select
        className="status-select"
        value={statusValue}
        onChange={(e) => onStatusChange(e.target.value)}
      >
        {statusOptions.map((status) => (
          <option key={status} value={status}>
            {status}
          </option>
        ))}
      </select>
    </div>
  );
};

export default SearchFilterBar;
