import React from "react";

const getColor = (percentage) => {
  if (percentage > 90) return "#d9364f";
  if (percentage >= 70) return "#e8a53d";
  return "#3f9f5f";
};

const CapacityBar = ({ current, total }) => {
  const safeTotal = total > 0 ? total : 1;
  const percentage = Math.min(100, Math.round((current / safeTotal) * 100));
  const color = getColor(percentage);

  return (
    <div className="capacity-bar" title={`${current} / ${total}`}>
      <div className="capacity-bar-track">
        <div
          className="capacity-bar-fill"
          style={{ width: `${percentage}%`, backgroundColor: color }}
        />
      </div>
      <span className="capacity-bar-label">
        {current}/{total} ({percentage}%)
      </span>
    </div>
  );
};

export default CapacityBar;
