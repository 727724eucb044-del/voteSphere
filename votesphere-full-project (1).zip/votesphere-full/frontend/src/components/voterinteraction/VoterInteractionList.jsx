import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchAllInteractions } from "../../store/slices/voterInteractionSlice";
import EmptyState from "../common/EmptyState";
import LoadingSpinner from "../common/LoadingSpinner";
import ErrorHandler from "../ErrorHandler";

const VoterInteractionList = () => {
  const dispatch = useDispatch();
  const { logs, isloading, iserror } = useSelector((state) => state.voterInteractions);

  useEffect(() => {
    dispatch(fetchAllInteractions());
  }, [dispatch]);

  return (
    <div className="page voter-interaction-list">
      <div className="page-header">
        <h1>Field Engagement Interaction Logs</h1>
      </div>

      <ErrorHandler error={iserror} />

      {isloading ? (
        <LoadingSpinner />
      ) : !logs || logs.length === 0 ? (
        <EmptyState message="No field engagement logs found." />
      ) : (
        <table className="domain-table">
          <thead>
            <tr>
              <th>Volunteer</th>
              <th>Voter</th>
              <th>Channel</th>
              <th>Sentiment</th>
              <th>Notes</th>
            </tr>
          </thead>
          <tbody>
            {logs.map((log) => (
              <tr key={log.interactionId}>
                <td>{log.volunteerName || log.volunteerId}</td>
                <td>{log.voterName || log.voterId}</td>
                <td>{log.interactionChannel}</td>
                <td>{log.sentimentDetected}</td>
                <td>{log.interactionNotes}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default VoterInteractionList;
