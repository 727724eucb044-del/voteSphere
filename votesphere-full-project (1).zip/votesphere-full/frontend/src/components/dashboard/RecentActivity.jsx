import React from "react";
import EmptyState from "../common/EmptyState";

const formatTimestamp = (value) => {
  if (!value) return "";
  const date = new Date(value);
  return Number.isNaN(date.getTime()) ? value : date.toLocaleString();
};

const RecentActivity = ({ items = [] }) => {
  if (!items || !items.length) {
    return <EmptyState message="No recent activity found." />;
  }

  return (
    <ul className="recent-activity">
      {items.map((item, idx) => (
        <li key={item.id || idx} className="recent-activity-item">
          <span className="activity-text">{item.text}</span>
          <span className="activity-timestamp">{formatTimestamp(item.timestamp)}</span>
        </li>
      ))}
    </ul>
  );
};

export default RecentActivity;
