import React from "react";

const StatCards = ({ totalEvents = 0, pendingMobilizations = 0, targetVoters = 0 }) => {
  return (
    <div className="stat-cards">
      <div className="stat-card">
        <span className="stat-card-label">Total Events</span>
        <span className="stat-card-value">{totalEvents}</span>
      </div>
      <div className="stat-card">
        <span className="stat-card-label">Pending Mobilizations</span>
        <span className="stat-card-value">{pendingMobilizations}</span>
      </div>
      <div className="stat-card">
        <span className="stat-card-label">Target Voters</span>
        <span className="stat-card-value">{targetVoters}</span>
      </div>
    </div>
  );
};

export default StatCards;
