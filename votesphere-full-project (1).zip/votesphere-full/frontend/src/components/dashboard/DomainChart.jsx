import React from "react";

// Accepts data as an array of { label, count } sentiment entries and renders
// proportional-height bars relative to the largest count in the set.
const DomainChart = ({ data = [] } = {}) => {
  const safeData = Array.isArray(data) ? data : [];
  const maxCount = Math.max(1, ...safeData.map((d) => d.count || 0));

  if (!safeData.length) {
    return <div className="domain-chart-empty">No sentiment data available.</div>;
  }

  return (
    <div className="domain-chart">
      {safeData.map((entry) => {
        const heightPct = Math.round(((entry.count || 0) / maxCount) * 100);
        return (
          <div className="domain-chart-column" key={entry.label}>
            <div
              className="domain-chart-bar"
              style={{ height: `${heightPct}%` }}
              title={`${entry.label}: ${entry.count}`}
            />
            <span className="domain-chart-label">{entry.label}</span>
            <span className="domain-chart-count">{entry.count}</span>
          </div>
        );
      })}
    </div>
  );
};

export default DomainChart;
