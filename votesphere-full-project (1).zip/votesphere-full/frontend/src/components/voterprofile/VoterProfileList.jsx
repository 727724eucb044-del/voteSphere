import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchVoterProfiles, deleteProfile } from "../../store/slices/voterProfileSlice";
import EmptyState from "../common/EmptyState";
import SearchFilterBar from "../common/SearchFilterBar";
import LoadingSpinner from "../common/LoadingSpinner";
import ErrorHandler from "../ErrorHandler";

const VoterProfileList = () => {
  const dispatch = useDispatch();
  const { items, isloading, iserror } = useSelector((state) => state.voterProfiles);
  const { role } = useSelector((state) => state.auth);

  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("ALL");

  useEffect(() => {
    dispatch(fetchVoterProfiles());
  }, [dispatch]);

  const isDirector = role === "CAMPAIGN_DIRECTOR";

  const filteredItems = (items || []).filter((voter) => {
    const fullName = `${voter.firstName} ${voter.lastName}`.toLowerCase();
    const matchesSearch =
      !search ||
      fullName.includes(search.toLowerCase()) ||
      (voter.electoralDistrict || "").toLowerCase().includes(search.toLowerCase());
    const matchesStatus = status === "ALL" || voter.engagementStatus === status;
    return matchesSearch && matchesStatus;
  });

  const handlePurge = (id) => {
    if (window.confirm("Are you sure you want to purge this voter record?")) {
      dispatch(deleteProfile(id));
    }
  };

  return (
    <div className="page voter-profile-list">
      <div className="page-header">
        <h1>Demographic Registry Dashboard</h1>
      </div>

      <SearchFilterBar
        searchValue={search}
        onSearchChange={setSearch}
        statusValue={status}
        onStatusChange={setStatus}
        statusOptions={["ALL", "UNCONTACTED", "CONTACTED", "FOLLOW_UP_REQUIRED"]}
        searchPlaceholder="Search by name or district"
      />

      <ErrorHandler error={iserror} />

      {isloading ? (
        <LoadingSpinner />
      ) : filteredItems.length === 0 ? (
        <EmptyState message="No voter demographic profiles indexed in registry." />
      ) : (
        <table className="domain-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>District</th>
              <th>Support Score</th>
              <th>Status</th>
              {isDirector && <th>Actions</th>}
            </tr>
          </thead>
          <tbody>
            {filteredItems.map((voter) => (
              <tr key={voter.voterId}>
                <td>
                  {voter.firstName} {voter.lastName}
                </td>
                <td>{voter.electoralDistrict}</td>
                <td>{voter.supportScore}</td>
                <td>{voter.engagementStatus}</td>
                {isDirector && (
                  <td className="row-actions">
                    <button type="button" onClick={() => handlePurge(voter.voterId)}>
                      Purge Record
                    </button>
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default VoterProfileList;
