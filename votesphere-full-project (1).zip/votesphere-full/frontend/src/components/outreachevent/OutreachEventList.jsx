import React, { useEffect, useMemo, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchOutreachEvents, deleteOutreachEvent } from "../../store/slices/outreachEventSlice";
import OutreachEventForm from "./OutreachEventForm";
import EmptyState from "../common/EmptyState";
import SearchFilterBar from "../common/SearchFilterBar";
import CapacityBar from "../common/CapacityBar";
import StatusBadge from "../common/StatusBadge";
import LoadingSpinner from "../common/LoadingSpinner";
import ErrorHandler from "../ErrorHandler";

const OutreachEventList = () => {
  const dispatch = useDispatch();
  const { items, isloading, iserror } = useSelector((state) => state.outreachEvents);
  const { role } = useSelector((state) => state.auth);

  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("ALL");
  const [formOpen, setFormOpen] = useState(false);
  const [editingEvent, setEditingEvent] = useState(null);

  useEffect(() => {
    dispatch(fetchOutreachEvents());
  }, [dispatch]);

  const canManage = role === "CAMPAIGN_DIRECTOR" || role === "FIELD_ORGANIZER";
  const canDelete = role === "CAMPAIGN_DIRECTOR";

  const filteredItems = useMemo(() => {
    return (items || []).filter((event) => {
      const matchesSearch =
        !search ||
        event.eventTitle.toLowerCase().includes(search.toLowerCase()) ||
        event.location.toLowerCase().includes(search.toLowerCase());
      const matchesStatus = status === "ALL" || event.eventStatus === status;
      return matchesSearch && matchesStatus;
    });
  }, [items, search, status]);

  const openCreate = () => {
    setEditingEvent(null);
    setFormOpen(true);
  };

  const openEdit = (event) => {
    setEditingEvent(event);
    setFormOpen(true);
  };

  const closeForm = () => {
    setFormOpen(false);
    setEditingEvent(null);
    dispatch(fetchOutreachEvents());
  };

  const handleDelete = (id) => {
    if (window.confirm("Are you sure you want to delete this outreach event?")) {
      dispatch(deleteOutreachEvent(id));
    }
  };

  return (
    <div className="page outreach-event-list">
      <div className="page-header">
        <h1>Campaign Outreach Event Drives</h1>
        {canManage && (
          <button type="button" className="submit-btn" onClick={openCreate}>
            + New Outreach Event
          </button>
        )}
      </div>

      <SearchFilterBar
        searchValue={search}
        onSearchChange={setSearch}
        statusValue={status}
        onStatusChange={setStatus}
        searchPlaceholder="Search by title or location"
      />

      <ErrorHandler error={iserror} />

      {isloading ? (
        <LoadingSpinner />
      ) : filteredItems.length === 0 ? (
        <EmptyState message="No campaign events have been fully authorized or published yet." />
      ) : (
        <table className="domain-table">
          <thead>
            <tr>
              <th>Title</th>
              <th>Type</th>
              <th>Location</th>
              <th>Scheduled</th>
              <th>Capacity</th>
              <th>Status</th>
              {(canManage || canDelete) && <th>Actions</th>}
            </tr>
          </thead>
          <tbody>
            {filteredItems.map((event) => (
              <tr key={event.eventId}>
                <td>{event.eventTitle}</td>
                <td>{event.eventType}</td>
                <td>{event.location}</td>
                <td>{event.scheduledDate ? new Date(event.scheduledDate).toLocaleString() : ""}</td>
                <td>
                  <CapacityBar
                    current={event.currentRegistrations || 0}
                    total={event.targetCapacity || 0}
                  />
                </td>
                <td>
                  <StatusBadge status={event.eventStatus} />
                </td>
                {(canManage || canDelete) && (
                  <td className="row-actions">
                    {canManage && (
                      <button type="button" onClick={() => openEdit(event)}>
                        Edit
                      </button>
                    )}
                    {canDelete && (
                      <button type="button" onClick={() => handleDelete(event.eventId)}>
                        Delete
                      </button>
                    )}
                  </td>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {formOpen && <OutreachEventForm event={editingEvent} onClose={closeForm} />}
    </div>
  );
};

export default OutreachEventList;
