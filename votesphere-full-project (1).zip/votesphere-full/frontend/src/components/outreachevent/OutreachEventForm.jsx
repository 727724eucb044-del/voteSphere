import React, { useState } from "react";
import { useDispatch } from "react-redux";
import { createOutreachEvent, updateOutreachEvent } from "../../store/slices/outreachEventSlice";

const EVENT_TYPES = ["RALLY", "PHONE_BANK", "TOWN_HALL", "DOOR_TO_DOOR"];

const toDatetimeLocal = (value) => {
  if (!value) return "";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "";
  const pad = (n) => String(n).padStart(2, "0");
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}T${pad(
    date.getHours()
  )}:${pad(date.getMinutes())}`;
};

const OutreachEventForm = ({ event, onClose }) => {
  const dispatch = useDispatch();
  const isEdit = Boolean(event && event.eventId);

  const [eventTitle, setEventTitle] = useState(event?.eventTitle || "");
  const [eventType, setEventType] = useState(event?.eventType || EVENT_TYPES[0]);
  const [location, setLocation] = useState(event?.location || "");
  const [scheduledDate, setScheduledDate] = useState(toDatetimeLocal(event?.scheduledDate));
  const [targetCapacity, setTargetCapacity] = useState(event?.targetCapacity || 10);

  const requiredFieldsFilled = eventTitle && eventType && location && scheduledDate;

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!requiredFieldsFilled) return;

    const dto = {
      eventTitle,
      eventType,
      location,
      scheduledDate,
      targetCapacity: Number(targetCapacity),
      eventStatus: event?.eventStatus || "PLANNED",
    };

    const action = isEdit
      ? updateOutreachEvent({ id: event.eventId, dto })
      : createOutreachEvent(dto);

    const result = await dispatch(action);
    if (!result.error) {
      alert("OutreachEvent created successfully!");
      onClose();
    }
  };

  return (
    <div className="modal-overlay">
      <div className="modal">
        <div className="modal-header">
          <h2>{isEdit ? "Edit Campaign Drive" : "Publish New Outreach Event"}</h2>
          <button type="button" className="modal-close" onClick={onClose} aria-label="Close">
            ×
          </button>
        </div>

        <form onSubmit={handleSubmit} className="modal-body">
          <div className="form-field">
            <label htmlFor="eventTitle">Event Campaign Title *</label>
            <input
              id="eventTitle"
              type="text"
              placeholder="District 4 Rally"
              value={eventTitle}
              onChange={(e) => setEventTitle(e.target.value)}
              required
            />
          </div>

          <div className="form-field">
            <label htmlFor="eventType">Drive Strategy Type *</label>
            <select
              id="eventType"
              value={eventType}
              onChange={(e) => setEventType(e.target.value)}
              required
            >
              {EVENT_TYPES.map((type) => (
                <option key={type} value={type}>
                  {type.replace(/_/g, " ")}
                </option>
              ))}
            </select>
          </div>

          <div className="form-field">
            <label htmlFor="location">Location Secure Description *</label>
            <input
              id="location"
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              required
            />
          </div>

          <div className="form-field">
            <label htmlFor="scheduledDate">Scheduled Runtime Stamp *</label>
            <input
              id="scheduledDate"
              type="datetime-local"
              value={scheduledDate}
              onChange={(e) => setScheduledDate(e.target.value)}
              required
            />
          </div>

          <div className="form-field">
            <label htmlFor="targetCapacity">Target Capacity</label>
            <input
              id="targetCapacity"
              type="number"
              min={1}
              value={targetCapacity}
              onChange={(e) => setTargetCapacity(e.target.value)}
            />
          </div>

          <button
            type="submit"
            className="submit-btn"
            disabled={!requiredFieldsFilled}
          >
            Authorize Campaign Event
          </button>
        </form>
      </div>
    </div>
  );
};

export default OutreachEventForm;
