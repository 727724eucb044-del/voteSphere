import React, { useEffect, useMemo } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchOutreachEvents } from "../store/slices/outreachEventSlice";
import { fetchVoterProfiles } from "../store/slices/voterProfileSlice";
import { fetchInteractionFeed } from "../store/slices/voterInteractionSlice";
import StatCards from "./dashboard/StatCards";
import DomainChart from "./dashboard/DomainChart";
import RecentActivity from "./dashboard/RecentActivity";
import LoadingSpinner from "./common/LoadingSpinner";

const SENTIMENT_LABELS = ["STRONG_SUPPORT", "LEANING", "UNDECIDED", "OPPOSED"];

const HomePage = () => {
  const dispatch = useDispatch();
  const { items: events, isloading: eventsLoading } = useSelector((state) => state.outreachEvents);
  const { items: voters } = useSelector((state) => state.voterProfiles);
  const { logs } = useSelector((state) => state.voterInteractions);
  const { role, user } = useSelector((state) => state.auth);

  useEffect(() => {
    dispatch(fetchOutreachEvents());
    dispatch(fetchVoterProfiles());
    dispatch(fetchInteractionFeed());
  }, [dispatch]);

  const totalEvents = events?.length || 0;
  const pendingMobilizations = useMemo(
    () => (events || []).filter((e) => e.eventStatus === "PLANNED").length,
    [events]
  );
  const targetVoters = useMemo(
    () => (events || []).reduce((sum, e) => sum + (e.targetCapacity || 0), 0),
    [events]
  );

  const sentimentData = useMemo(() => {
    const counts = SENTIMENT_LABELS.reduce((acc, label) => {
      acc[label] = 0;
      return acc;
    }, {});
    (voters || []).forEach((v) => {
      // Voter profiles don't carry raw sentiment, so approximate distribution
      // from support score bands until a dedicated metrics call is wired in.
      if (v.supportScore >= 75) counts.STRONG_SUPPORT += 1;
      else if (v.supportScore >= 50) counts.LEANING += 1;
      else if (v.supportScore >= 25) counts.UNDECIDED += 1;
      else counts.OPPOSED += 1;
    });
    return SENTIMENT_LABELS.map((label) => ({
      label: label.replace(/_/g, " "),
      count: counts[label],
    }));
  }, [voters]);

  const activityItems = useMemo(
    () =>
      (logs || [])
        .slice(-8)
        .reverse()
        .map((log) => ({
          id: log.interactionId,
          text: `${log.volunteerName || "A volunteer"} logged a ${
            log.sentimentDetected || "new"
          } interaction via ${log.interactionChannel || "field contact"}`,
          timestamp: log.loggedAt,
        })),
    [logs]
  );

  return (
    <div className="page home-page">
      <div className="page-header">
        <h1>VoteSphere Dashboard</h1>
        {user && <span className="dashboard-subtitle">Welcome back, {user}</span>}
      </div>

      {eventsLoading ? (
        <LoadingSpinner />
      ) : (
        <StatCards
          totalEvents={totalEvents}
          pendingMobilizations={pendingMobilizations}
          targetVoters={targetVoters}
        />
      )}

      <div className="dashboard-grid">
        <div className="dashboard-panel">
          <h2>Voter Sentiment Distribution</h2>
          <DomainChart data={sentimentData} />
        </div>

        <div className="dashboard-panel">
          <h2>Recent Activity</h2>
          <RecentActivity items={activityItems} />
        </div>
      </div>

      {!role && (
        <p className="home-guest-note">
          Sign in to access campaign operations, voter registry, and shift scheduling.
        </p>
      )}
    </div>
  );
};

export default HomePage;
