import React, { useEffect } from "react";
import { useDispatch, useSelector } from "react-redux";
import { fetchCampaignStaff } from "../../store/slices/campaignAccountSlice";
import EmptyState from "../common/EmptyState";
import LoadingSpinner from "../common/LoadingSpinner";
import ErrorHandler from "../ErrorHandler";

const CampaignStaffList = () => {
  const dispatch = useDispatch();
  const { staffMembers, isloading, iserror } = useSelector((state) => state.campaignStaff);

  useEffect(() => {
    dispatch(fetchCampaignStaff());
  }, [dispatch]);

  return (
    <div className="page campaign-staff-list">
      <div className="page-header">
        <h1>Staff Management</h1>
      </div>

      <ErrorHandler error={iserror} />

      {isloading ? (
        <LoadingSpinner />
      ) : !staffMembers || staffMembers.length === 0 ? (
        <EmptyState message="No campaign staff members found." />
      ) : (
        <table className="domain-table">
          <thead>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Role</th>
              <th>Phone</th>
            </tr>
          </thead>
          <tbody>
            {staffMembers.map((member) => (
              <tr key={member.accountId}>
                <td>{member.fullName}</td>
                <td>{member.email}</td>
                <td>{member.domainRole}</td>
                <td>{member.phoneNumber}</td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
};

export default CampaignStaffList;
