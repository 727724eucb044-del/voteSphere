import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import {
  fetchShifts,
  reserveShiftSlot,
  deleteShift,
} from "../../store/slices/volunteerShiftSlice";
import VolunteerShiftForm from "./VolunteerShiftForm";
import EmptyState from "../common/EmptyState";
import LoadingSpinner from "../common/LoadingSpinner";
import StatusBadge from "../common/StatusBadge";
import ErrorHandler from "../ErrorHandler";

const VolunteerShiftList = () => {
  const dispatch = useDispatch();
  const { shifts, isloading, iserror } = useSelector((state) => state.volunteerShifts);
  const { role } = useSelector((state) => state.auth);
  const accountId = localStorage.getItem("votesphere_accountId");

  const [formOpen, setFormOpen] = useState(false);

  useEffect(() => {
    dispatch(fetchShifts());
  }, [dispatch]);

  const isVolunteer = role === "OUTREACH_VOLUNTEER";
  const canManage = role === "CAMPAIGN_DIRECTOR" || role === "FIELD_ORGANIZER";
  const canDelete = role === "CAMPAIGN_DIRECTOR";

  const handleClaim = (shiftId) => {
    dispatch(reserveShiftSlot({ shiftId, accountId }));
  };

  const handleWithdraw = (shiftId) => {
    if (window.confirm("Withdraw from this shift?")) {
      dispatch(deleteShift(shiftId));
    }
  };

  const closeForm = () => {
    setFormOpen(false);
    dispatch(fetchShifts());
  };

  return (
    <div className="page volunteer-shift-list">
      <div className="page-header">
        <h1>Operations Shift Schedule</h1>
        {canManage && (
          <button type="button" className="submit-btn" onClick={() => setFormOpen(true)}>
            + Allocate Shift
          </button>
        )}
      </div>

      <ErrorHandler error={iserror} />

      {isloading ? (
        <LoadingSpinner />
      ) : !shifts || shifts.length === 0 ? (
        <EmptyState message="No shifts have been scheduled yet." />
      ) : (
        <table className="domain-table">
          <thead>
            <tr>
              <th>Event</th>
              <th>Start</th>
              <th>End</th>
              <th>Status</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody>
            {shifts.map((shift) => (
              <tr key={shift.shiftId}>
                <td>{shift.eventId}</td>
                <td>{shift.startTime ? new Date(shift.startTime).toLocaleString() : ""}</td>
                <td>{shift.endTime ? new Date(shift.endTime).toLocaleString() : ""}</td>
                <td>
                  <StatusBadge status={shift.shiftStatus} />
                </td>
                <td className="row-actions">
                  {isVolunteer && shift.shiftStatus === "OPEN" && (
                    <button type="button" onClick={() => handleClaim(shift.shiftId)}>
                      Claim Shift
                    </button>
                  )}
                  {isVolunteer && shift.shiftStatus === "RESERVED" && (
                    <button type="button" onClick={() => handleWithdraw(shift.shiftId)}>
                      Withdraw
                    </button>
                  )}
                  {canDelete && (
                    <button type="button" onClick={() => handleWithdraw(shift.shiftId)}>
                      Delete
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}

      {formOpen && <VolunteerShiftForm onClose={closeForm} />}
    </div>
  );
};

export default VolunteerShiftList;
