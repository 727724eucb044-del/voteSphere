import React, { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { createShift } from "../../store/slices/volunteerShiftSlice";
import { fetchOutreachEvents } from "../../store/slices/outreachEventSlice";

const VolunteerShiftForm = ({ onClose }) => {
  const dispatch = useDispatch();
  const { items: events } = useSelector((state) => state.outreachEvents);

  const [eventId, setEventId] = useState("");
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");
  const [boundsError, setBoundsError] = useState("");

  useEffect(() => {
    if (!events || events.length === 0) {
      dispatch(fetchOutreachEvents());
    }
  }, [dispatch, events]);

  const selectedEvent = (events || []).find((e) => String(e.eventId) === String(eventId));

  const validateWithinEventBounds = (start, end) => {
    if (!selectedEvent || !selectedEvent.scheduledDate) return "";
    const eventStart = new Date(selectedEvent.scheduledDate);
    const startDate = start ? new Date(start) : null;
    const endDate = end ? new Date(end) : null;

    if (startDate && startDate < eventStart) {
      return "Shift start time cannot be before the parent event's scheduled runtime.";
    }
    if (startDate && endDate && endDate <= startDate) {
      return "Shift end time must be after the shift start time.";
    }
    return "";
  };

  const handleStartChange = (value) => {
    setStartTime(value);
    setBoundsError(validateWithinEventBounds(value, endTime));
  };

  const handleEndChange = (value) => {
    setEndTime(value);
    setBoundsError(validateWithinEventBounds(startTime, value));
  };

  const requiredFieldsFilled = eventId && startTime && endTime && !boundsError;

  const handleSubmit = async (e) => {
    e.preventDefault();
    const validationMessage = validateWithinEventBounds(startTime, endTime);
    if (validationMessage) {
      setBoundsError(validationMessage);
      return;
    }

    const dto = {
      eventId: Number(eventId),
      startTime,
      endTime,
      shiftStatus: "OPEN",
    };

    const result = await dispatch(createShift(dto));
    if (!result.error) {
      onClose();
    }
  };

  return (
    <div className="modal-overlay">
      <div className="modal">
        <div className="modal-header">
          <h2>Allocate Mobilization Shift</h2>
          <button type="button" className="modal-close" onClick={onClose} aria-label="Close">
            ×
          </button>
        </div>

        <form onSubmit={handleSubmit} className="modal-body">
          <div className="form-field">
            <label htmlFor="eventId">Outreach Event *</label>
            <select
              id="eventId"
              value={eventId}
              onChange={(e) => setEventId(e.target.value)}
              required
            >
              <option value="" disabled>
                Select an event
              </option>
              {(events || []).map((ev) => (
                <option key={ev.eventId} value={ev.eventId}>
                  {ev.eventTitle}
                </option>
              ))}
            </select>
          </div>

          <div className="form-field">
            <label htmlFor="startTime">Shift Start Time</label>
            <input
              id="startTime"
              type="datetime-local"
              value={startTime}
              onChange={(e) => handleStartChange(e.target.value)}
              required
            />
          </div>

          <div className="form-field">
            <label htmlFor="endTime">Shift End Time</label>
            <input
              id="endTime"
              type="datetime-local"
              value={endTime}
              onChange={(e) => handleEndChange(e.target.value)}
              required
            />
          </div>

          {boundsError && <div className="error-message">{boundsError}</div>}

          <button type="submit" className="submit-btn" disabled={!requiredFieldsFilled}>
            Allocate Shift
          </button>
        </form>
      </div>
    </div>
  );
};

export default VolunteerShiftForm;
