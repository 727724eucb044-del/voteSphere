import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import volunteerShiftService from "../../services/volunteerShiftService";

const initialState = {
  shifts: [],
  isloading: false,
  iserror: null,
};

const extractMessage = (error, fallback) =>
  (error.response && error.response.data && error.response.data.message) ||
  error.message ||
  fallback;

export const fetchShifts = createAsyncThunk("shifts/getAll", async (_, thunkAPI) => {
  try {
    return await volunteerShiftService.getAllShifts();
  } catch (error) {
    return thunkAPI.rejectWithValue(extractMessage(error, "Unable to load the shift schedule."));
  }
});

export const createShift = createAsyncThunk(
  "shifts/create",
  async (dto, thunkAPI) => {
    try {
      return await volunteerShiftService.createShift(dto);
    } catch (error) {
      return thunkAPI.rejectWithValue(extractMessage(error, "Unable to allocate shift."));
    }
  }
);

export const reserveShiftSlot = createAsyncThunk(
  "shifts/reserve",
  async ({ shiftId, accountId }, thunkAPI) => {
    try {
      return await volunteerShiftService.reserveShift(shiftId, accountId);
    } catch (error) {
      return thunkAPI.rejectWithValue(
        extractMessage(error, "Maximum of 5 active shift registrations allowed.")
      );
    }
  }
);

export const updateShiftStatus = createAsyncThunk(
  "shifts/updateStatus",
  async ({ id, status }, thunkAPI) => {
    try {
      return await volunteerShiftService.updateShiftStatus(id, status);
    } catch (error) {
      return thunkAPI.rejectWithValue(extractMessage(error, "Unable to update shift status."));
    }
  }
);

export const deleteShift = createAsyncThunk(
  "shifts/delete",
  async (id, thunkAPI) => {
    try {
      await volunteerShiftService.deleteShift(id);
      return id;
    } catch (error) {
      return thunkAPI.rejectWithValue(extractMessage(error, "Unable to withdraw shift."));
    }
  }
);

const volunteerShiftSlice = createSlice({
  name: "volunteerShifts",
  initialState,
  reducers: {
    reset: (state) => {
      state.isloading = false;
      state.iserror = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchShifts.pending, (state) => {
        state.isloading = true;
      })
      .addCase(fetchShifts.fulfilled, (state, action) => {
        state.isloading = false;
        state.shifts = action.payload;
      })
      .addCase(fetchShifts.rejected, (state, action) => {
        state.isloading = false;
        state.iserror = action.payload;
      })
      .addCase(createShift.fulfilled, (state, action) => {
        state.shifts.push(action.payload);
      })
      .addCase(createShift.rejected, (state, action) => {
        state.iserror = action.payload;
      })
      .addCase(reserveShiftSlot.fulfilled, (state, action) => {
        const idx = state.shifts.findIndex((s) => s.shiftId === action.payload.shiftId);
        if (idx !== -1) state.shifts[idx] = action.payload;
      })
      .addCase(reserveShiftSlot.rejected, (state, action) => {
        state.iserror = action.payload;
      })
      .addCase(updateShiftStatus.fulfilled, (state, action) => {
        const idx = state.shifts.findIndex((s) => s.shiftId === action.payload.shiftId);
        if (idx !== -1) state.shifts[idx] = action.payload;
      })
      .addCase(deleteShift.fulfilled, (state, action) => {
        state.shifts = state.shifts.filter((s) => s.shiftId !== action.payload);
      })
      .addCase(deleteShift.rejected, (state, action) => {
        state.iserror = action.payload;
      });
  },
});

export const { reset } = volunteerShiftSlice.actions;
export default volunteerShiftSlice.reducer;
