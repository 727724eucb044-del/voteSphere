import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import voterProfileService from "../../services/voterProfileService";

const initialState = {
  items: [],
  metrics: null,
  isloading: false,
  iserror: null,
};

const extractMessage = (error, fallback) =>
  (error.response && error.response.data && error.response.data.message) ||
  error.message ||
  fallback;

export const fetchVoterProfiles = createAsyncThunk(
  "voters/getAll",
  async (_, thunkAPI) => {
    try {
      return await voterProfileService.getAllVoters();
    } catch (error) {
      return thunkAPI.rejectWithValue(extractMessage(error, "Unable to load voter profiles."));
    }
  }
);

export const createVoterProfile = createAsyncThunk(
  "voters/create",
  async (dto, thunkAPI) => {
    try {
      return await voterProfileService.createVoter(dto);
    } catch (error) {
      return thunkAPI.rejectWithValue(extractMessage(error, "Unable to create voter profile."));
    }
  }
);

export const updateVoterProfile = createAsyncThunk(
  "voters/update",
  async ({ id, dto }, thunkAPI) => {
    try {
      return await voterProfileService.updateVoter(id, dto);
    } catch (error) {
      return thunkAPI.rejectWithValue(extractMessage(error, "Unable to update voter profile."));
    }
  }
);

export const deleteProfile = createAsyncThunk(
  "voters/delete",
  async (id, thunkAPI) => {
    try {
      await voterProfileService.deleteVoter(id);
      return id;
    } catch (error) {
      return thunkAPI.rejectWithValue(extractMessage(error, "Unable to purge voter record."));
    }
  }
);

export const fetchDistrictMetrics = createAsyncThunk(
  "voters/districtMetrics",
  async (district, thunkAPI) => {
    try {
      return await voterProfileService.getDistrictMetrics(district);
    } catch (error) {
      return thunkAPI.rejectWithValue(extractMessage(error, "Unable to load district metrics."));
    }
  }
);

const voterProfileSlice = createSlice({
  name: "voterProfiles",
  initialState,
  reducers: {
    reset: (state) => {
      state.isloading = false;
      state.iserror = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchVoterProfiles.pending, (state) => {
        state.isloading = true;
      })
      .addCase(fetchVoterProfiles.fulfilled, (state, action) => {
        state.isloading = false;
        state.items = action.payload;
      })
      .addCase(fetchVoterProfiles.rejected, (state, action) => {
        state.isloading = false;
        state.iserror = action.payload;
      })
      .addCase(createVoterProfile.fulfilled, (state, action) => {
        state.items.push(action.payload);
      })
      .addCase(createVoterProfile.rejected, (state, action) => {
        state.iserror = action.payload;
      })
      .addCase(updateVoterProfile.fulfilled, (state, action) => {
        const idx = state.items.findIndex((v) => v.voterId === action.payload.voterId);
        if (idx !== -1) state.items[idx] = action.payload;
      })
      .addCase(updateVoterProfile.rejected, (state, action) => {
        state.iserror = action.payload;
      })
      .addCase(deleteProfile.fulfilled, (state, action) => {
        state.items = state.items.filter((v) => v.voterId !== action.payload);
      })
      .addCase(deleteProfile.rejected, (state, action) => {
        state.iserror = action.payload;
      })
      .addCase(fetchDistrictMetrics.fulfilled, (state, action) => {
        state.metrics = action.payload;
      })
      .addCase(fetchDistrictMetrics.rejected, (state, action) => {
        state.iserror = action.payload;
      });
  },
});

export const { reset } = voterProfileSlice.actions;
export default voterProfileSlice.reducer;
