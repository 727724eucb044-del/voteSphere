import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import authService from "../../services/authService";

const storedRole = localStorage.getItem("votesphere_role");
const storedToken = localStorage.getItem("votesphere_jwt");
const storedEmail = localStorage.getItem("votesphere_email");

const initialState = {
  user: storedEmail || null,
  role: storedRole || null,
  token: storedToken || null,
  isloading: false,
  iserror: null,
  message: "",
};

const persistSession = (payload) => {
  if (payload.token) localStorage.setItem("votesphere_jwt", payload.token);
  if (payload.domainRole) localStorage.setItem("votesphere_role", payload.domainRole);
  if (payload.accountId != null)
    localStorage.setItem("votesphere_accountId", String(payload.accountId));
  if (payload.fullName) localStorage.setItem("votesphere_fullName", payload.fullName);
  if (payload.email) localStorage.setItem("votesphere_email", payload.email);
};

export const loginUser = createAsyncThunk(
  "auth/login",
  async (credentials, thunkAPI) => {
    try {
      return await authService.login(credentials);
    } catch (error) {
      const message =
        (error.response && error.response.data && error.response.data.message) ||
        error.message ||
        "Unable to sign in.";
      return thunkAPI.rejectWithValue(message);
    }
  }
);

export const registerUser = createAsyncThunk(
  "auth/register",
  async (registrationData, thunkAPI) => {
    try {
      return await authService.register(registrationData);
    } catch (error) {
      const message =
        (error.response && error.response.data && error.response.data.message) ||
        error.message ||
        "Unable to create access key.";
      return thunkAPI.rejectWithValue(message);
    }
  }
);

const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    logout: (state) => {
      Object.keys(localStorage)
        .filter((key) => key.startsWith("votesphere_"))
        .forEach((key) => localStorage.removeItem(key));
      state.user = null;
      state.role = null;
      state.token = null;
      state.isloading = false;
      state.iserror = null;
      state.message = "";
    },
    resetAuthStatus: (state) => {
      state.iserror = null;
      state.message = "";
    },
    // Injects mock credentials for instant domain exploration without a real login round trip.
    staticBypassLogin: (state, action) => {
      state.token = action.payload.token;
      state.role = action.payload.role;
      state.user = action.payload.accountId;
      persistSession({
        token: action.payload.token,
        domainRole: action.payload.role,
        accountId: action.payload.accountId,
      });
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(loginUser.pending, (state) => {
        state.isloading = true;
        state.iserror = null;
        state.message = "";
      })
      .addCase(loginUser.fulfilled, (state, action) => {
        state.isloading = false;
        state.user = action.payload.email;
        state.role = action.payload.domainRole;
        state.token = action.payload.token;
        persistSession(action.payload);
      })
      .addCase(loginUser.rejected, (state, action) => {
        state.isloading = false;
        state.iserror = true;
        state.message = action.payload || "Unable to sign in.";
      })
      .addCase(registerUser.pending, (state) => {
        state.isloading = true;
        state.iserror = null;
        state.message = "";
      })
      .addCase(registerUser.fulfilled, (state, action) => {
        state.isloading = false;
        state.user = action.payload.email;
        state.role = action.payload.domainRole;
        state.token = action.payload.token;
        persistSession(action.payload);
      })
      .addCase(registerUser.rejected, (state, action) => {
        state.isloading = false;
        state.iserror = true;
        state.message = action.payload || "Unable to create access key.";
      });
  },
});

export const { logout, resetAuthStatus, staticBypassLogin } = authSlice.actions;
export default authSlice.reducer;
