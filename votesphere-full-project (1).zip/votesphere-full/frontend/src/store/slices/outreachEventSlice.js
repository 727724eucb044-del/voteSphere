import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import outreachEventService from "../../services/outreachEventService";

const initialState = {
  items: [],
  isloading: false,
  iserror: null,
  currentEvent: null,
};

const extractMessage = (error, fallback) =>
  (error.response && error.response.data && error.response.data.message) ||
  error.message ||
  fallback;

export const fetchOutreachEvents = createAsyncThunk(
  "events/getAll",
  async (_, thunkAPI) => {
    try {
      return await outreachEventService.getAllEvents();
    } catch (error) {
      return thunkAPI.rejectWithValue(extractMessage(error, "Unable to load outreach events."));
    }
  }
);

export const createOutreachEvent = createAsyncThunk(
  "events/create",
  async (dto, thunkAPI) => {
    try {
      await outreachEventService.createEvent(dto);
      // Backend responds with a plain confirmation string, so echo the submitted
      // drive back into the registry until the next full refresh.
      return { ...dto, eventStatus: dto.eventStatus || "PLANNED" };
    } catch (error) {
      return thunkAPI.rejectWithValue(extractMessage(error, "Unable to create outreach event."));
    }
  }
);

export const updateOutreachEvent = createAsyncThunk(
  "events/update",
  async ({ id, dto }, thunkAPI) => {
    try {
      await outreachEventService.updateEvent(id, dto);
      return { eventId: id, ...dto };
    } catch (error) {
      return thunkAPI.rejectWithValue(extractMessage(error, "Unable to update outreach event."));
    }
  }
);

export const deleteOutreachEvent = createAsyncThunk(
  "events/delete",
  async (id, thunkAPI) => {
    try {
      await outreachEventService.deleteEvent(id);
      return id;
    } catch (error) {
      return thunkAPI.rejectWithValue(extractMessage(error, "Unable to delete outreach event."));
    }
  }
);

export const concludeOutreachEvent = createAsyncThunk(
  "events/conclude",
  async (id, thunkAPI) => {
    try {
      return await outreachEventService.concludeEvent(id);
    } catch (error) {
      return thunkAPI.rejectWithValue(extractMessage(error, "Unable to conclude outreach event."));
    }
  }
);

const outreachEventSlice = createSlice({
  name: "outreachEvents",
  initialState,
  reducers: {
    reset: (state) => {
      state.isloading = false;
      state.iserror = null;
    },
    setCurrentEvent: (state, action) => {
      state.currentEvent = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchOutreachEvents.pending, (state) => {
        state.isloading = true;
        state.iserror = null;
      })
      .addCase(fetchOutreachEvents.fulfilled, (state, action) => {
        state.isloading = false;
        state.items = action.payload;
      })
      .addCase(fetchOutreachEvents.rejected, (state, action) => {
        state.isloading = false;
        state.iserror = action.payload;
      })
      .addCase(createOutreachEvent.fulfilled, (state, action) => {
        state.items.push(action.payload);
      })
      .addCase(createOutreachEvent.rejected, (state, action) => {
        state.iserror = action.payload;
      })
      .addCase(updateOutreachEvent.fulfilled, (state, action) => {
        const idx = state.items.findIndex((e) => e.eventId === action.payload.eventId);
        if (idx !== -1) state.items[idx] = { ...state.items[idx], ...action.payload };
      })
      .addCase(updateOutreachEvent.rejected, (state, action) => {
        state.iserror = action.payload;
      })
      .addCase(deleteOutreachEvent.fulfilled, (state, action) => {
        state.items = state.items.filter((e) => e.eventId !== action.payload);
      })
      .addCase(deleteOutreachEvent.rejected, (state, action) => {
        state.iserror = action.payload;
      })
      .addCase(concludeOutreachEvent.fulfilled, (state, action) => {
        const idx = state.items.findIndex((e) => e.eventId === action.payload.eventId);
        if (idx !== -1) state.items[idx] = action.payload;
      });
  },
});

export const { reset, setCurrentEvent } = outreachEventSlice.actions;
export default outreachEventSlice.reducer;
