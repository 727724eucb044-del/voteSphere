import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import voterInteractionService from "../../services/voterInteractionService";

const initialState = {
  logs: [],
  isloading: false,
  iserror: null,
};

const extractMessage = (error, fallback) =>
  (error.response && error.response.data && error.response.data.message) ||
  error.message ||
  fallback;

export const fetchAllInteractions = createAsyncThunk(
  "interactions/getAll",
  async (_, thunkAPI) => {
    try {
      return await voterInteractionService.getAllInteractions();
    } catch (error) {
      return thunkAPI.rejectWithValue(extractMessage(error, "Unable to load engagement logs."));
    }
  }
);

export const logInteraction = createAsyncThunk(
  "interactions/log",
  async (dto, thunkAPI) => {
    try {
      return await voterInteractionService.logInteraction(dto);
    } catch (error) {
      return thunkAPI.rejectWithValue(extractMessage(error, "Unable to log interaction."));
    }
  }
);

export const fetchInteractionFeed = createAsyncThunk(
  "interactions/recentFeed",
  async (_, thunkAPI) => {
    try {
      return await voterInteractionService.getRecentFeed();
    } catch (error) {
      return thunkAPI.rejectWithValue(extractMessage(error, "Unable to load recent activity."));
    }
  }
);

const voterInteractionSlice = createSlice({
  name: "voterInteractions",
  initialState,
  reducers: {
    reset: (state) => {
      state.isloading = false;
      state.iserror = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchAllInteractions.pending, (state) => {
        state.isloading = true;
      })
      .addCase(fetchAllInteractions.fulfilled, (state, action) => {
        state.isloading = false;
        state.logs = action.payload;
      })
      .addCase(fetchAllInteractions.rejected, (state, action) => {
        state.isloading = false;
        state.iserror = action.payload;
      })
      .addCase(logInteraction.fulfilled, (state, action) => {
        state.logs.push(action.payload);
      })
      .addCase(logInteraction.rejected, (state, action) => {
        state.iserror = action.payload;
      })
      .addCase(fetchInteractionFeed.fulfilled, (state, action) => {
        state.logs = action.payload;
      })
      .addCase(fetchInteractionFeed.rejected, (state, action) => {
        state.iserror = action.payload;
      });
  },
});

export const { reset } = voterInteractionSlice.actions;
export default voterInteractionSlice.reducer;
