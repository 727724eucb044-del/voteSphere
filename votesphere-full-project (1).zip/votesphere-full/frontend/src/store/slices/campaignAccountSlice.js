import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import campaignStaffService from "../../services/campaignStaffService";

const initialState = {
  staffMembers: [],
  isloading: false,
  iserror: null,
};

const extractMessage = (error, fallback) =>
  (error.response && error.response.data && error.response.data.message) ||
  error.message ||
  fallback;

export const fetchCampaignStaff = createAsyncThunk(
  "staff/getAll",
  async (_, thunkAPI) => {
    try {
      return await campaignStaffService.getAllStaff();
    } catch (error) {
      return thunkAPI.rejectWithValue(extractMessage(error, "Unable to load staff registry."));
    }
  }
);

const campaignAccountSlice = createSlice({
  name: "campaignStaff",
  initialState,
  reducers: {
    reset: (state) => {
      state.isloading = false;
      state.iserror = null;
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchCampaignStaff.pending, (state) => {
        state.isloading = true;
      })
      .addCase(fetchCampaignStaff.fulfilled, (state, action) => {
        state.isloading = false;
        state.staffMembers = action.payload;
      })
      .addCase(fetchCampaignStaff.rejected, (state, action) => {
        state.isloading = false;
        state.iserror = action.payload;
      });
  },
});

export const { reset } = campaignAccountSlice.actions;
export default campaignAccountSlice.reducer;
