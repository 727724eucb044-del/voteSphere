import { configureStore } from "@reduxjs/toolkit";
import authReducer from "./slices/authSlice";
import outreachEventReducer from "./slices/outreachEventSlice";
import voterProfileReducer from "./slices/voterProfileSlice";
import volunteerShiftReducer from "./slices/volunteerShiftSlice";
import voterInteractionReducer from "./slices/voterInteractionSlice";
import campaignStaffReducer from "./slices/campaignAccountSlice";

export const store = configureStore({
  reducer: {
    auth: authReducer,
    outreachEvents: outreachEventReducer,
    voterProfiles: voterProfileReducer,
    volunteerShifts: volunteerShiftReducer,
    voterInteractions: voterInteractionReducer,
    campaignStaff: campaignStaffReducer,
  },
});

export default store;
