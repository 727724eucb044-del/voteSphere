import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";

import Navbar from "./components/layout/Navbar";
import HomePage from "./components/HomePage";
import Login from "./components/Login";
import OutreachEventList from "./components/outreachevent/OutreachEventList";
import VoterProfileList from "./components/voterprofile/VoterProfileList";
import VoterInteractionList from "./components/voterinteraction/VoterInteractionList";
import VolunteerShiftList from "./components/volunteershift/VolunteerShiftList";
import CampaignStaffList from "./components/campaignstaff/CampaignStaffList";
import ProtectedRoute from "./routes/ProtectedRoute";

function App() {
  return (
    <div className="app-shell">
      <BrowserRouter>
        <Navbar />
        <main className="app-content">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/login" element={<Login />} />
            <Route path="/register" element={<Login />} />

            <Route
              path="/events"
              element={
                <ProtectedRoute
                  allowedRoles={[
                    "CAMPAIGN_DIRECTOR",
                    "FIELD_ORGANIZER",
                    "OUTREACH_VOLUNTEER",
                    "COMPLIANCE_AUDITOR",
                  ]}
                >
                  <OutreachEventList />
                </ProtectedRoute>
              }
            />

            <Route
              path="/voters"
              element={
                <ProtectedRoute
                  allowedRoles={["CAMPAIGN_DIRECTOR", "FIELD_ORGANIZER", "OUTREACH_VOLUNTEER"]}
                >
                  <VoterProfileList />
                </ProtectedRoute>
              }
            />

            <Route
              path="/interactions"
              element={
                <ProtectedRoute
                  allowedRoles={["CAMPAIGN_DIRECTOR", "FIELD_ORGANIZER", "COMPLIANCE_AUDITOR"]}
                >
                  <VoterInteractionList />
                </ProtectedRoute>
              }
            />

            <Route
              path="/shifts"
              element={
                <ProtectedRoute
                  allowedRoles={["CAMPAIGN_DIRECTOR", "FIELD_ORGANIZER", "OUTREACH_VOLUNTEER"]}
                >
                  <VolunteerShiftList />
                </ProtectedRoute>
              }
            />

            <Route
              path="/staff"
              element={
                <ProtectedRoute allowedRoles={["CAMPAIGN_DIRECTOR"]}>
                  <CampaignStaffList />
                </ProtectedRoute>
              }
            />
          </Routes>
        </main>
      </BrowserRouter>
    </div>
  );
}

export default App;
