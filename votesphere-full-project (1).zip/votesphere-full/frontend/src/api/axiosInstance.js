import axios from "axios";

const BASE_URL = process.env.REACT_APP_API_BASE_URL || "http://localhost:8080/api";

const axiosInstance = axios.create({
  baseURL: BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

// Attach the staff session JWT to every outgoing request when present.
axiosInstance.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem("votesphere_jwt");
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Normalize error responses so slices can read a consistent message.
axiosInstance.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      localStorage.removeItem("votesphere_jwt");
      localStorage.removeItem("votesphere_role");
      localStorage.removeItem("votesphere_accountId");
      localStorage.removeItem("votesphere_fullName");
    }
    return Promise.reject(error);
  }
);

export default axiosInstance;
