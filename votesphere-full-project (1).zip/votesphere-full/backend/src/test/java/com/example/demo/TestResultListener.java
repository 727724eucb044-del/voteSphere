package com.example.demo;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

/**
 * Lightweight TestNG listener that prints a concise pass/fail line for every
 * test method so results are easy to scan in the console/CI log.
 */
public class TestResultListener implements ITestListener {

    @Override
    public void onTestStart(ITestResult result) {
        System.out.println("[START] " + result.getMethod().getMethodName());
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        System.out.println("[PASS]  " + result.getMethod().getMethodName());
    }

    @Override
    public void onTestFailure(ITestResult result) {
        System.out.println("[FAIL]  " + result.getMethod().getMethodName()
                + " -> " + (result.getThrowable() != null ? result.getThrowable().getMessage() : "unknown error"));
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        System.out.println("[SKIP]  " + result.getMethod().getMethodName());
    }

    @Override
    public void onFinish(ITestContext context) {
        System.out.println(String.format(
                "TestNG summary: %d passed, %d failed, %d skipped",
                context.getPassedTests().size(),
                context.getFailedTests().size(),
                context.getSkippedTests().size()
        ));
    }
}
