package com.example.demo;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Table;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.Query;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;
import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

@Listeners({TestResultListener.class})
public class ProjectValidationTests {
   private static final String PRIMARY_ENTITY = "com.example.demo.entity.OutreachEvent";
   private static final String PRIMARY_CONTROLLER = "com.example.demo.controller.OutreachEventController";
   private static final String SECONDARY_CONTROLLER = "com.example.demo.controller.VoterProfileController";
   private static final String PRIMARY_SERVICE = "com.example.demo.service.OutreachManagementService";
   private static final String PRIMARY_REPOSITORY = "com.example.demo.repository.OutreachEventRepository";
   private static final String DTO_PATH = "com.example.demo.dto.OutreachEventDto";
   private static final String JWT_CLASS_PATH = "com.example.demo.service.JwtService";
   private static final String TABLE_NAME = "outreach_events";
   private static final String API_BASE_PATH = "/api/events";
   private static final String DOMAIN_ROLE = "FIELD_ORGANIZER";
   private static final String AUTH_EMAIL = "admin@votesphere.org";
   private static final String DOMAIN_VALUE_1 = "Grand Rally for Democracy";
   private static final String CRUD_DELETE_MSG = "OutreachEvent deleted successfully.";
   private static final String CRUD_CREATE_MSG = "OutreachEvent created successfully.";
   private static final String CRUD_UPDATE_MSG = "OutreachEvent updated successfully.";
   private static final String SEC_DELETE_MSG = "VoterProfile deleted successfully.";

   public ProjectValidationTests() {
   }

   @Test
   public void t1_primaryControllerVerification() throws Exception {
      Class<?> clazz = Class.forName("com.example.demo.controller.OutreachEventController");
      Assert.assertNotNull(clazz);
      Method[] methods = clazz.getDeclaredMethods();
      Assert.assertTrue(methods.length > 0);
   }

   @Test
   public void t2_primaryServiceVerification() throws Exception {
      Class<?> clazz = Class.forName("com.example.demo.service.OutreachManagementService");
      Assert.assertNotNull(clazz);
      Method[] methods = clazz.getDeclaredMethods();
      Assert.assertTrue(methods.length >= 3);
   }

   @Test
   public void t3_primaryRepositoryVerification() throws Exception {
      Class<?> clazz = Class.forName("com.example.demo.repository.OutreachEventRepository");
      Assert.assertTrue(clazz.isInterface());
      Assert.assertTrue(Arrays.stream(clazz.getInterfaces()).anyMatch((i) -> i.getSimpleName().contains("JpaRepository")));
   }

   @Test
   public void t4_primaryEntityVerification() throws Exception {
      Class<?> clazz = Class.forName("com.example.demo.entity.OutreachEvent");
      Assert.assertNotNull(clazz.getAnnotation(Entity.class));
      Table table = (Table)clazz.getAnnotation(Table.class);
      Assert.assertNotNull(table);
      Assert.assertEquals(table.name(), "outreach_events");
   }

   @Test
   public void t5_securityConfigVerification() throws Exception {
      Class<?> clazz = Class.forName("com.example.demo.config.SecurityConfig");
      Assert.assertNotNull(clazz.getAnnotation(Configuration.class));
      Method filterChain = clazz.getDeclaredMethod("securityFilterChain", HttpSecurity.class);
      Assert.assertNotNull(filterChain.getAnnotation(Bean.class));
   }

   @Test
   public void t6_controllerMappingVerification() throws Exception {
      Class<?> clazz = Class.forName("com.example.demo.controller.OutreachEventController");
      RequestMapping rm = (RequestMapping)clazz.getAnnotation(RequestMapping.class);
      Assert.assertEquals(rm.value()[0], "/api/events");
   }

   @Test
   public void t7_getAllVerification() throws Exception {
      Class<?> ctrlClazz = Class.forName("com.example.demo.controller.OutreachEventController");
      Method getAllMethod = (Method)Arrays.stream(ctrlClazz.getDeclaredMethods()).filter((m) -> m.getName().toLowerCase().contains("getall")).findFirst().get();
      Assert.assertNotNull(getAllMethod);
   }

   @Test
   public void t8_deleteVerification() throws Exception {
      Class<?> ctrlClazz = Class.forName("com.example.demo.controller.OutreachEventController");
      Method deleteMethod = (Method)Arrays.stream(ctrlClazz.getDeclaredMethods()).filter((m) -> m.getName().toLowerCase().contains("delete")).findFirst().get();
      Assert.assertNotNull(deleteMethod);
   }

   @Test
   public void t9_createVerification() throws Exception {
      Class<?> ctrlClazz = Class.forName("com.example.demo.controller.OutreachEventController");
      Method createMethod = (Method)Arrays.stream(ctrlClazz.getDeclaredMethods()).filter((m) -> m.getName().toLowerCase().contains("publish") || m.getName().toLowerCase().contains("create")).findFirst().get();
      Assert.assertNotNull(createMethod);
   }

   @Test
   public void t10_updateVerification() throws Exception {
      Class<?> ctrlClazz = Class.forName("com.example.demo.controller.OutreachEventController");
      Method updateMethod = (Method)Arrays.stream(ctrlClazz.getDeclaredMethods()).filter((m) -> m.getName().toLowerCase().contains("update")).findFirst().get();
      Assert.assertNotNull(updateMethod);
   }

   @Test
   public void t11_getByIdVerification() throws Exception {
      Class<?> ctrlClazz = Class.forName("com.example.demo.controller.OutreachEventController");
      Method getByIdMethod = (Method)Arrays.stream(ctrlClazz.getDeclaredMethods()).filter((m) -> m.getName().toLowerCase().contains("byid")).findFirst().get();
      Assert.assertNotNull(getByIdMethod);
   }

   @Test
   public void t12_secondaryDeleteVerification() throws Exception {
      Class<?> ctrlClazz = Class.forName("com.example.demo.controller.VoterProfileController");
      Method deleteMethod = (Method)Arrays.stream(ctrlClazz.getDeclaredMethods()).filter((m) -> m.getName().toLowerCase().contains("delete")).findFirst().get();
      Assert.assertNotNull(deleteMethod);
   }

   @Test
   public void t13_adminSecurityVerification() throws Exception {
      Class<?> clazz = Class.forName("com.example.demo.controller.OutreachEventController");
      Method method = (Method)Arrays.stream(clazz.getDeclaredMethods()).filter((m) -> m.isAnnotationPresent(PreAuthorize.class) && ((PreAuthorize)m.getAnnotation(PreAuthorize.class)).value().contains("DIRECTOR")).findFirst().get();
      Assert.assertNotNull(method);
   }

   @Test
   public void t14_roleSecurityVerification() throws Exception {
      Class<?> clazz = Class.forName("com.example.demo.controller.OutreachEventController");
      Method method = (Method)Arrays.stream(clazz.getDeclaredMethods()).filter((m) -> m.isAnnotationPresent(PreAuthorize.class) && ((PreAuthorize)m.getAnnotation(PreAuthorize.class)).value().contains("FIELD_ORGANIZER")).findFirst().get();
      Assert.assertNotNull(method);
   }

   @Test
   public void t15_corsConfigurationVerification() throws Exception {
      Class<?> clazz = Class.forName("com.example.demo.config.SecurityConfig");
      Assert.assertTrue(Arrays.stream(clazz.getDeclaredMethods()).anyMatch((m) -> m.getName().toLowerCase().contains("cors")));
   }

   @Test
   public void t16_validationAnnotationVerification() throws Exception {
      Class<?> dtoClazz = Class.forName("com.example.demo.dto.OutreachEventDto");
      Assert.assertTrue(Arrays.stream(dtoClazz.getDeclaredFields()).anyMatch((f) -> f.getDeclaredAnnotations().length > 0));
   }

   @Test
   public void t17_transactionalVerification() throws Exception {
      Class<?> clazz = Class.forName("com.example.demo.service.OutreachManagementService");
      Assert.assertTrue(clazz.isAnnotationPresent(Service.class) || clazz.isAnnotationPresent(Transactional.class));
   }

   @Test
   public void t18_repositoryFindByVerification() throws Exception {
      Class<?> clazz = Class.forName("com.example.demo.repository.OutreachEventRepository");
      Assert.assertTrue(Arrays.stream(clazz.getDeclaredMethods()).anyMatch((m) -> m.getName().startsWith("findBy") || m.getName().startsWith("findAll")));
   }

   @Test
   public void t19_repositoryQueryVerification() throws Exception {
      Class<?> clazz = Class.forName("com.example.demo.repository.OutreachEventRepository");
      Assert.assertTrue(clazz.isInterface());
      Assert.assertTrue(Arrays.stream(clazz.getDeclaredMethods()).anyMatch((m) -> m.getName().startsWith("findBy") || m.isAnnotationPresent(Query.class)));
   }

   @Test
   public void t20_globalExceptionHandlerVerification() throws Exception {
      Class<?> handlerClazz = Class.forName("com.example.demo.exception.GlobalExceptionHandler");
      Assert.assertTrue(handlerClazz.isAnnotationPresent(ControllerAdvice.class));
   }

   @Test
   public void t21_notFoundHandlingVerification() throws Exception {
      Class<?> handlerClazz = Class.forName("com.example.demo.exception.GlobalExceptionHandler");
      Object handler = handlerClazz.getDeclaredConstructor().newInstance();
      Method m = (Method)Arrays.stream(handlerClazz.getDeclaredMethods()).filter((me) -> me.isAnnotationPresent(ExceptionHandler.class) && Arrays.toString(((ExceptionHandler)me.getAnnotation(ExceptionHandler.class)).value()).contains("RuntimeException")).findFirst().get();
      ResponseEntity<?> re = (ResponseEntity)m.invoke(handler, new RuntimeException("Error"));
      Assert.assertEquals(re.getStatusCode(), HttpStatus.BAD_REQUEST);
   }

   @Test
   public void t22_conflictHandlingVerification() throws Exception {
      Class<?> handlerClazz = Class.forName("com.example.demo.exception.GlobalExceptionHandler");
      Assert.assertTrue(Arrays.stream(handlerClazz.getDeclaredMethods()).anyMatch((m) -> m.isAnnotationPresent(ExceptionHandler.class)));
   }

   @Test
   public void t23_jwtSecretPrivacyVerification() throws Exception {
      Class<?> clazz = Class.forName("com.example.demo.service.JwtService");
      Field f = (Field)Arrays.stream(clazz.getDeclaredFields()).filter((fi) -> fi.getName().toLowerCase().contains("secret")).findFirst().get();
      Assert.assertTrue(Modifier.isPrivate(f.getModifiers()));
   }

   @Test
   public void t24_jwtGenerationVerification() throws Exception {
      Class<?> clazz = Class.forName("com.example.demo.service.JwtService");
      Object service = clazz.getDeclaredConstructor().newInstance();
      Field fSecret = clazz.getDeclaredField("secretKey");
      fSecret.setAccessible(true);
      fSecret.set(service, "9a4f2c8d3b7a1e6f45c8a0b3f267d8b1d4e6f3c8a9d2b5f8e3a9c8b5f6v8a3d9");
      Field fExp = clazz.getDeclaredField("jwtExpiration");
      fExp.setAccessible(true);
      fExp.set(service, 3600000L);
      Method m = clazz.getMethod("generateToken", String.class, String.class, Long.class);
      String token = (String)m.invoke(service, "admin@votesphere.org", "FIELD_ORGANIZER", 1L);
      Assert.assertNotNull(token);
   }

   @Test
   public void t25_jwtValidationRoundTrip() throws Exception {
      Class<?> clazz = Class.forName("com.example.demo.service.JwtService");
      Object service = clazz.getDeclaredConstructor().newInstance();
      Field fSecret = clazz.getDeclaredField("secretKey");
      fSecret.setAccessible(true);
      fSecret.set(service, "9a4f2c8d3b7a1e6f45c8a0b3f267d8b1d4e6f3c8a9d2b5f8e3a9c8b5f6v8a3d9");
      Field fExp = clazz.getDeclaredField("jwtExpiration");
      fExp.setAccessible(true);
      fExp.set(service, 3600000L);
      String token = (String)clazz.getMethod("generateToken", String.class, String.class, Long.class).invoke(service, "admin@votesphere.org", "FIELD_ORGANIZER", 1L);
      boolean isValid = (Boolean)clazz.getMethod("isTokenValid", String.class, String.class).invoke(service, token, "admin@votesphere.org");
      Assert.assertTrue(isValid);
   }

   @Test
   public void t26_jwtExtractionVerification() throws Exception {
      Class<?> clazz = Class.forName("com.example.demo.service.JwtService");
      Object service = clazz.getDeclaredConstructor().newInstance();
      Field fSecret = clazz.getDeclaredField("secretKey");
      fSecret.setAccessible(true);
      fSecret.set(service, "9a4f2c8d3b7a1e6f45c8a0b3f267d8b1d4e6f3c8a9d2b5f8e3a9c8b5f6v8a3d9");
      Field fExp = clazz.getDeclaredField("jwtExpiration");
      fExp.setAccessible(true);
      fExp.set(service, 3600000L);
      String token = (String)clazz.getMethod("generateToken", String.class, String.class, Long.class).invoke(service, "admin@votesphere.org", "FIELD_ORGANIZER", 1L);
      String username = (String)clazz.getMethod("extractUsername", String.class).invoke(service, token);
      Assert.assertEquals(username, "admin@votesphere.org");
   }

   @Test
   public void t27_tableNameVerification() throws Exception {
      Class<?> clazz = Class.forName("com.example.demo.entity.OutreachEvent");
      Table t = (Table)clazz.getAnnotation(Table.class);
      Assert.assertEquals(t.name(), "outreach_events");
   }

   @Test
   public void t28_constraintsVerification() throws Exception {
      Class<?> clazz = Class.forName("com.example.demo.entity.OutreachEvent");
      Assert.assertTrue(Arrays.stream(clazz.getDeclaredFields()).anyMatch((f) -> f.isAnnotationPresent(Column.class)));
   }

   @Test
   public void t29_relationshipVerification() throws Exception {
      Class<?> clazz = Class.forName("com.example.demo.entity.VoterInteraction");
      Assert.assertTrue(Arrays.stream(clazz.getDeclaredFields()).anyMatch((f) -> f.isAnnotationPresent(JoinColumn.class)));
   }

   @Test
   public void t30_filterChainBeanVerification() throws Exception {
      Class<?> clazz = Class.forName("com.example.demo.config.SecurityConfig");
      Assert.assertTrue(Arrays.stream(clazz.getDeclaredMethods()).anyMatch((m) -> m.isAnnotationPresent(Bean.class)));
   }
}
