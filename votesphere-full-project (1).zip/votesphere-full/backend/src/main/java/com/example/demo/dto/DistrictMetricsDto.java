package com.example.demo.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Map;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DistrictMetricsDto {
    private String district;
    private Long totalRegisteredVoters;
    private Double averageSupportScore;
    private Map<String, Long> sentimentDistribution;
}
