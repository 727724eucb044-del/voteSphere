package com.example.demo.controller;

import com.example.demo.dto.DistrictMetricsDto;
import com.example.demo.dto.VoterProfileDto;
import com.example.demo.service.VoterEngagementService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/voters")
@RequiredArgsConstructor
public class VoterProfileController {

    private final VoterEngagementService voterEngagementService;

    @GetMapping
    @PreAuthorize("hasAnyAuthority('CAMPAIGN_DIRECTOR', 'FIELD_ORGANIZER', 'OUTREACH_VOLUNTEER')")
    public ResponseEntity<List<VoterProfileDto>> getAllVoters() {
        return ResponseEntity.ok(voterEngagementService.getAllProfiles());
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('CAMPAIGN_DIRECTOR', 'FIELD_ORGANIZER', 'OUTREACH_VOLUNTEER')")
    public ResponseEntity<VoterProfileDto> getVoterById(@PathVariable Long id) {
        return ResponseEntity.ok(voterEngagementService.getProfileById(id));
    }

    @PostMapping
    @PreAuthorize("hasAnyAuthority('CAMPAIGN_DIRECTOR', 'FIELD_ORGANIZER')")
    public ResponseEntity<VoterProfileDto> createVoter(@RequestBody VoterProfileDto dto) {
        VoterProfileDto created = voterEngagementService.createVoterProfile(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('CAMPAIGN_DIRECTOR', 'FIELD_ORGANIZER')")
    public ResponseEntity<VoterProfileDto> updateVoter(@PathVariable Long id, @RequestBody VoterProfileDto dto) {
        return ResponseEntity.ok(voterEngagementService.updateProfile(id, dto));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('CAMPAIGN_DIRECTOR')")
    public ResponseEntity<String> deleteVoter(@PathVariable Long id) {
        voterEngagementService.deleteProfile(id);
        return ResponseEntity.ok("VoterProfile deleted successfully.");
    }

    @GetMapping("/district-metrics")
    @PreAuthorize("hasAnyAuthority('CAMPAIGN_DIRECTOR', 'FIELD_ORGANIZER')")
    public ResponseEntity<DistrictMetricsDto> getDistrictMetrics(@RequestParam String district) {
        return ResponseEntity.ok(voterEngagementService.calculateDistrictSupportMetrics(district));
    }
}
