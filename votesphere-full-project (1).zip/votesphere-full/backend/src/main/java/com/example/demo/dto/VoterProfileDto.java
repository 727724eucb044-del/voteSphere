package com.example.demo.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VoterProfileDto {
    private Long voterId;
    private String firstName;
    private String lastName;
    private String electoralDistrict;
    private String contactNumber;
    private Integer supportScore;
    private String engagementStatus;
    private LocalDateTime lastContactedDate;
}
