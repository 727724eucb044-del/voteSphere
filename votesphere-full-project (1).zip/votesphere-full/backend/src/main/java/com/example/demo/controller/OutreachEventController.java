package com.example.demo.controller;

import com.example.demo.dto.OutreachEventDto;
import com.example.demo.service.OutreachManagementService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/events")
@RequiredArgsConstructor
public class OutreachEventController {

    private final OutreachManagementService outreachManagementService;

    @GetMapping
    @PreAuthorize("hasAnyAuthority('CAMPAIGN_DIRECTOR', 'FIELD_ORGANIZER', 'OUTREACH_VOLUNTEER', 'COMPLIANCE_AUDITOR')")
    public ResponseEntity<List<OutreachEventDto>> getAllEvents() {
        return ResponseEntity.ok(outreachManagementService.getAllEvents());
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('CAMPAIGN_DIRECTOR', 'FIELD_ORGANIZER', 'OUTREACH_VOLUNTEER', 'COMPLIANCE_AUDITOR')")
    public ResponseEntity<OutreachEventDto> getEventById(@PathVariable Long id) {
        return ResponseEntity.ok(outreachManagementService.getEventById(id));
    }

    @PostMapping
    @PreAuthorize("hasAnyAuthority('CAMPAIGN_DIRECTOR', 'FIELD_ORGANIZER')")
    public ResponseEntity<String> createEvent(@Valid @RequestBody OutreachEventDto dto) {
        outreachManagementService.publishOutreachEvent(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body("OutreachEvent created successfully.");
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyAuthority('CAMPAIGN_DIRECTOR', 'FIELD_ORGANIZER')")
    public ResponseEntity<String> updateEvent(@PathVariable Long id, @RequestBody OutreachEventDto dto) {
        outreachManagementService.updateEvent(id, dto);
        return ResponseEntity.ok("OutreachEvent updated successfully.");
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('CAMPAIGN_DIRECTOR')")
    public ResponseEntity<String> deleteEvent(@PathVariable Long id) {
        outreachManagementService.deleteEvent(id);
        return ResponseEntity.ok("OutreachEvent deleted successfully.");
    }

    @PostMapping("/{id}/conclude")
    @PreAuthorize("hasAnyAuthority('CAMPAIGN_DIRECTOR', 'FIELD_ORGANIZER')")
    public ResponseEntity<OutreachEventDto> concludeEvent(@PathVariable Long id) {
        return ResponseEntity.ok(outreachManagementService.concludeEventWorkflows(id));
    }
}
