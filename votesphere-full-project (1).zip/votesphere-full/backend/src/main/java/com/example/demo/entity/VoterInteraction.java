package com.example.demo.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "voter_interactions")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VoterInteraction {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long interactionId;

    @ManyToOne
    @JoinColumn(name = "voter_id", nullable = false)
    private VoterProfile voter;

    @ManyToOne
    @JoinColumn(name = "volunteer_id", nullable = false)
    private CampaignAccount volunteer;

    @Enumerated(EnumType.STRING)
    @Column(name = "interaction_channel")
    private InteractionChannel interactionChannel;

    @Enumerated(EnumType.STRING)
    @Column(name = "sentiment_detected")
    private Sentiment sentimentDetected;

    private String policyIssueTag;

    @Column(name = "interaction_notes", length = 1000)
    private String interactionNotes;

    @Column(updatable = false)
    private LocalDateTime loggedAt;

    @PrePersist
    protected void onCreate() {
        this.loggedAt = LocalDateTime.now();
    }

    public enum InteractionChannel {
        CALL, SMS, IN_PERSON
    }

    public enum Sentiment {
        STRONG_SUPPORT, LEANING, UNDECIDED, OPPOSED
    }
}
