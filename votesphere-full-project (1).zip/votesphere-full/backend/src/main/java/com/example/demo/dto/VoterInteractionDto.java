package com.example.demo.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VoterInteractionDto {
    private Long interactionId;
    private Long voterId;
    private Long volunteerId;
    private String interactionChannel;
    private String sentimentDetected;
    private String policyIssueTag;
    private String interactionNotes;
}
