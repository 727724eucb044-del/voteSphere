package com.example.demo.config;

import com.example.demo.entity.CampaignAccount;
import com.example.demo.repository.CampaignAccountRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class CustomUserDetailsService implements UserDetailsService {

    private final CampaignAccountRepository campaignAccountRepository;

    @Override
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        CampaignAccount account = campaignAccountRepository.findByEmail(email)
                .orElseThrow(() -> new UsernameNotFoundException("Account not found: " + email));

        return User.builder()
                .username(account.getEmail())
                .password(account.getPasswordHash())
                .authorities(new SimpleGrantedAuthority(account.getDomainRole()))
                .disabled(!account.isActive())
                .build();
    }
}
