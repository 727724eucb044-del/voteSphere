package com.example.demo.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "campaign_accounts")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CampaignAccount {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long accountId;

    @Email
    @NotNull
    @Column(unique = true, nullable = false, length = 150)
    private String email;

    @NotNull
    @Column(name = "password_hash", nullable = false)
    private String passwordHash;

    @Size(min = 2, max = 100)
    @Column(name = "full_name", nullable = false, length = 100)
    private String fullName;

    @Column(name = "domain_role", nullable = false, length = 50)
    
    private String domainRole;

    private String phoneNumber;

    @Builder.Default
    private boolean isActive = true;

    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
    }

    public enum Role {
        CAMPAIGN_DIRECTOR,
        FIELD_ORGANIZER,
        OUTREACH_VOLUNTEER,
        COMPLIANCE_AUDITOR
    }
}
