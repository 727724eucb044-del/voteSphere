package com.example.demo.service;

import com.example.demo.dto.DistrictMetricsDto;
import com.example.demo.dto.VoterProfileDto;
import com.example.demo.entity.VoterProfile;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repository.VoterInteractionRepository;
import com.example.demo.repository.VoterProfileRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class VoterEngagementService {

    private final VoterProfileRepository voterProfileRepository;
    private final VoterInteractionRepository voterInteractionRepository;

    @Transactional
    public VoterProfileDto createVoterProfile(VoterProfileDto dto) {
        VoterProfile profile = VoterProfile.builder()
                .firstName(dto.getFirstName())
                .lastName(dto.getLastName())
                .electoralDistrict(dto.getElectoralDistrict())
                .contactNumber(dto.getContactNumber())
                .supportScore(dto.getSupportScore() != null ? dto.getSupportScore() : 50)
                .engagementStatus(VoterProfile.EngagementStatus.UNCONTACTED)
                .build();

        VoterProfile saved = voterProfileRepository.save(profile);
        return toDto(saved);
    }

    public List<VoterProfileDto> getAllProfiles() {
        return voterProfileRepository.findAll().stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    public VoterProfileDto getProfileById(Long id) {
        VoterProfile profile = voterProfileRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("VoterProfile not found with id: " + id));
        return toDto(profile);
    }

    @Transactional
    public VoterProfileDto updateProfile(Long id, VoterProfileDto dto) {
        VoterProfile profile = voterProfileRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("VoterProfile not found with id: " + id));

        if (dto.getFirstName() != null) profile.setFirstName(dto.getFirstName());
        if (dto.getLastName() != null) profile.setLastName(dto.getLastName());
        if (dto.getElectoralDistrict() != null) profile.setElectoralDistrict(dto.getElectoralDistrict());
        if (dto.getContactNumber() != null) profile.setContactNumber(dto.getContactNumber());
        if (dto.getSupportScore() != null) profile.setSupportScore(dto.getSupportScore());

        VoterProfile saved = voterProfileRepository.save(profile);
        return toDto(saved);
    }

    @Transactional
    public void deleteProfile(Long id) {
        if (!voterProfileRepository.existsById(id)) {
            throw new ResourceNotFoundException("VoterProfile not found with id: " + id);
        }
        voterProfileRepository.deleteById(id);
    }

    /**
     * Aggregates data from the voter_profiles table to calculate average support
     * scores and sentiment distribution for a specific electoral district.
     */
    public DistrictMetricsDto calculateDistrictSupportMetrics(String district) {
        List<VoterProfile> profiles = voterProfileRepository.findByElectoralDistrict(district);

        Double avgSupport = voterProfileRepository.getAverageSupportScoreByDistrict(district);

        Map<String, Long> sentimentDistribution = new HashMap<>();
        long highSupport = profiles.stream().filter(p -> p.getSupportScore() >= 70).count();
        long undecided = profiles.stream().filter(p -> p.getSupportScore() >= 40 && p.getSupportScore() < 70).count();
        long opposed = profiles.stream().filter(p -> p.getSupportScore() < 40).count();
        sentimentDistribution.put("HIGH_SUPPORT", highSupport);
        sentimentDistribution.put("UNDECIDED", undecided);
        sentimentDistribution.put("OPPOSED", opposed);

        return DistrictMetricsDto.builder()
                .district(district)
                .totalRegisteredVoters((long) profiles.size())
                .averageSupportScore(avgSupport != null ? avgSupport : 0.0)
                .sentimentDistribution(sentimentDistribution)
                .build();
    }

    /**
     * Implements automated lifecycle transitions. Moves voters from UNCONTACTED to
     * CONTACTED upon first engagement and flags low-support profiles for mandatory
     * FOLLOW_UP_REQUIRED status.
     */
    @Transactional
    public void updateVoterStatusLifecycle(Long voterId) {
        VoterProfile profile = voterProfileRepository.findById(voterId)
                .orElseThrow(() -> new ResourceNotFoundException("VoterProfile not found with id: " + voterId));

        if (profile.getSupportScore() < 40) {
            profile.setEngagementStatus(VoterProfile.EngagementStatus.FOLLOW_UP_REQUIRED);
        } else if (profile.getEngagementStatus() == VoterProfile.EngagementStatus.UNCONTACTED) {
            profile.setEngagementStatus(VoterProfile.EngagementStatus.CONTACTED);
        }

        voterProfileRepository.save(profile);
    }

    private VoterProfileDto toDto(VoterProfile profile) {
        return VoterProfileDto.builder()
                .voterId(profile.getVoterId())
                .firstName(profile.getFirstName())
                .lastName(profile.getLastName())
                .electoralDistrict(profile.getElectoralDistrict())
                .contactNumber(profile.getContactNumber())
                .supportScore(profile.getSupportScore())
                .engagementStatus(profile.getEngagementStatus().name())
                .lastContactedDate(profile.getLastContactedDate())
                .build();
    }
}
