package com.example.demo.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "volunteer_shifts")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VolunteerShift {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long shiftId;

    @ManyToOne
    @JoinColumn(name = "event_id", nullable = false)
    private OutreachEvent event;

    @ManyToOne
    @JoinColumn(name = "assigned_volunteer")
    private CampaignAccount assignedVolunteer;

    @Column(nullable = false)
    private LocalDateTime startTime;

    @Column(nullable = false)
    private LocalDateTime endTime;

    @Enumerated(EnumType.STRING)
    @Column(name = "shift_status", nullable = false)
    private ShiftStatus shiftStatus;

    public enum ShiftStatus {
        OPEN, RESERVED, COMPLETED, MISSED
    }
}
