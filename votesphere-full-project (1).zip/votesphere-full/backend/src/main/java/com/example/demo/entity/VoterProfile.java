package com.example.demo.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "voter_profiles")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VoterProfile {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long voterId;

    @Column(nullable = false, length = 50)
    private String firstName;

    @Column(nullable = false, length = 50)
    private String lastName;

    @Column(name = "electoral_district", nullable = false, length = 100)
    private String electoralDistrict;

    private String contactNumber;

    @Min(0)
    @Max(100)
    @Column(name = "support_score", nullable = false)
    @Builder.Default
    private Integer supportScore = 50;

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private EngagementStatus engagementStatus = EngagementStatus.UNCONTACTED;

    private LocalDateTime lastContactedDate;

    public enum EngagementStatus {
        UNCONTACTED, CONTACTED, FOLLOW_UP_REQUIRED
    }
}
