package com.example.demo.service;

import com.example.demo.dto.OutreachEventDto;
import com.example.demo.entity.OutreachEvent;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repository.OutreachEventRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class OutreachManagementService {

    private final OutreachEventRepository outreachEventRepository;

    @Transactional
    public OutreachEventDto publishOutreachEvent(OutreachEventDto dto) {
        if (dto.getScheduledDate() == null || dto.getScheduledDate().isBefore(LocalDateTime.now())) {
            throw new RuntimeException("Scheduled date must be in the future");
        }

        OutreachEvent event = OutreachEvent.builder()
                .eventTitle(dto.getEventTitle())
                .eventType(OutreachEvent.EventType.valueOf(dto.getEventType()))
                .location(dto.getLocation())
                .scheduledDate(dto.getScheduledDate())
                .targetCapacity(dto.getTargetCapacity())
                .currentRegistrations(0)
                .eventStatus(OutreachEvent.EventStatus.PLANNED)
                .build();

        OutreachEvent saved = outreachEventRepository.save(event);
        return toDto(saved);
    }

    public List<OutreachEventDto> getAllEvents() {
        return outreachEventRepository.findAll().stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    public OutreachEventDto getEventById(Long id) {
        OutreachEvent event = outreachEventRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("OutreachEvent not found with id: " + id));
        return toDto(event);
    }

    @Transactional
    public OutreachEventDto updateEvent(Long id, OutreachEventDto dto) {
        OutreachEvent event = outreachEventRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("OutreachEvent not found with id: " + id));

        if (event.getEventStatus() == OutreachEvent.EventStatus.COMPLETED
                || event.getEventStatus() == OutreachEvent.EventStatus.CANCELLED) {
            throw new IllegalStateException("Cannot modify a finalized or cancelled outreach event");
        }

        if (dto.getEventTitle() != null) event.setEventTitle(dto.getEventTitle());
        if (dto.getEventType() != null) event.setEventType(OutreachEvent.EventType.valueOf(dto.getEventType()));
        if (dto.getLocation() != null) event.setLocation(dto.getLocation());
        if (dto.getScheduledDate() != null) event.setScheduledDate(dto.getScheduledDate());
        if (dto.getTargetCapacity() != null) event.setTargetCapacity(dto.getTargetCapacity());

        OutreachEvent saved = outreachEventRepository.save(event);
        return toDto(saved);
    }

    @Transactional
    public OutreachEventDto concludeEventWorkflows(Long id) {
        OutreachEvent event = outreachEventRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("OutreachEvent not found with id: " + id));

        if (event.getEventStatus() == OutreachEvent.EventStatus.COMPLETED
                || event.getEventStatus() == OutreachEvent.EventStatus.CANCELLED) {
            throw new IllegalStateException("Event is already finalized or cancelled");
        }

        event.setEventStatus(OutreachEvent.EventStatus.COMPLETED);
        OutreachEvent saved = outreachEventRepository.save(event);
        return toDto(saved);
    }

    @Transactional
    public void deleteEvent(Long id) {
        if (!outreachEventRepository.existsById(id)) {
            throw new ResourceNotFoundException("OutreachEvent not found with id: " + id);
        }
        outreachEventRepository.deleteById(id);
    }

    private OutreachEventDto toDto(OutreachEvent event) {
        return OutreachEventDto.builder()
                .eventId(event.getEventId())
                .eventTitle(event.getEventTitle())
                .eventType(event.getEventType().name())
                .location(event.getLocation())
                .scheduledDate(event.getScheduledDate())
                .targetCapacity(event.getTargetCapacity())
                .currentRegistrations(event.getCurrentRegistrations())
                .eventStatus(event.getEventStatus().name())
                .build();
    }
}
