package com.example.demo.service;

import com.example.demo.dto.VolunteerShiftDto;
import com.example.demo.entity.CampaignAccount;
import com.example.demo.entity.OutreachEvent;
import com.example.demo.entity.VolunteerShift;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.exception.ShiftLimitExceededException;
import com.example.demo.repository.CampaignAccountRepository;
import com.example.demo.repository.OutreachEventRepository;
import com.example.demo.repository.VolunteerShiftRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class VolunteerOperationsService {

    private static final int MAX_ACTIVE_SHIFTS = 5;

    private final VolunteerShiftRepository volunteerShiftRepository;
    private final OutreachEventRepository outreachEventRepository;
    private final CampaignAccountRepository campaignAccountRepository;

    @Transactional
    public VolunteerShiftDto reserveShiftSlot(Long shiftId, Long accountId) {
        VolunteerShift shift = volunteerShiftRepository.findByIdWithLock(shiftId)
                .orElseThrow(() -> new ResourceNotFoundException("VolunteerShift not found with id: " + shiftId));

        CampaignAccount volunteer = campaignAccountRepository.findById(accountId)
                .orElseThrow(() -> new ResourceNotFoundException("CampaignAccount not found with id: " + accountId));

        long activeShiftCount = volunteerShiftRepository.findByAssignedVolunteerAccountId(accountId).stream()
                .filter(s -> s.getShiftStatus() == VolunteerShift.ShiftStatus.RESERVED)
                .count();

        if (activeShiftCount >= MAX_ACTIVE_SHIFTS) {
            throw new ShiftLimitExceededException("Maximum of 5 active shift registrations allowed.");
        }

        shift.setAssignedVolunteer(volunteer);
        shift.setShiftStatus(VolunteerShift.ShiftStatus.RESERVED);

        VolunteerShift saved = volunteerShiftRepository.save(shift);
        return toDto(saved);
    }

    @Transactional
    public VolunteerShiftDto createShift(VolunteerShiftDto dto) {
        OutreachEvent event = outreachEventRepository.findById(dto.getEventId())
                .orElseThrow(() -> new ResourceNotFoundException("OutreachEvent not found with id: " + dto.getEventId()));

        VolunteerShift shift = VolunteerShift.builder()
                .event(event)
                .startTime(dto.getStartTime())
                .endTime(dto.getEndTime())
                .shiftStatus(VolunteerShift.ShiftStatus.OPEN)
                .build();

        VolunteerShift saved = volunteerShiftRepository.save(shift);
        return toDto(saved);
    }

    public List<VolunteerShiftDto> getAllShifts() {
        return volunteerShiftRepository.findAll().stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    public List<VolunteerShiftDto> getMySchedule(Long accountId) {
        return volunteerShiftRepository.findByAssignedVolunteerAccountId(accountId).stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    @Transactional
    public VolunteerShiftDto updateShiftStatus(Long shiftId, String status) {
        VolunteerShift shift = volunteerShiftRepository.findById(shiftId)
                .orElseThrow(() -> new ResourceNotFoundException("VolunteerShift not found with id: " + shiftId));
        shift.setShiftStatus(VolunteerShift.ShiftStatus.valueOf(status));
        VolunteerShift saved = volunteerShiftRepository.save(shift);
        return toDto(saved);
    }

    @Transactional
    public void deleteShift(Long shiftId) {
        if (!volunteerShiftRepository.existsById(shiftId)) {
            throw new ResourceNotFoundException("VolunteerShift not found with id: " + shiftId);
        }
        volunteerShiftRepository.deleteById(shiftId);
    }

    private VolunteerShiftDto toDto(VolunteerShift shift) {
        return VolunteerShiftDto.builder()
                .shiftId(shift.getShiftId())
                .eventId(shift.getEvent() != null ? shift.getEvent().getEventId() : null)
                .assignedVolunteerId(shift.getAssignedVolunteer() != null ? shift.getAssignedVolunteer().getAccountId() : null)
                .startTime(shift.getStartTime())
                .endTime(shift.getEndTime())
                .shiftStatus(shift.getShiftStatus().name())
                .build();
    }
}
