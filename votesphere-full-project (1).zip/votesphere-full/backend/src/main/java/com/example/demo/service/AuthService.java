package com.example.demo.service;

import com.example.demo.dto.AuthRequestDto;
import com.example.demo.dto.AuthResponseDto;
import com.example.demo.dto.RegisterDto;
import com.example.demo.entity.CampaignAccount;
import com.example.demo.repository.CampaignAccountRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final CampaignAccountRepository campaignAccountRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;

    @Transactional
    public AuthResponseDto register(RegisterDto dto) {
        if (campaignAccountRepository.findByEmail(dto.getEmail()).isPresent()) {
            throw new RuntimeException("Email is already registered");
        }

        CampaignAccount account = CampaignAccount.builder()
                .email(dto.getEmail())
                .passwordHash(passwordEncoder.encode(dto.getPassword()))
                .fullName(dto.getFullName())
                .domainRole(dto.getDomainRole())
                .phoneNumber(dto.getPhoneNumber())
                .isActive(true)
                .build();

        CampaignAccount saved = campaignAccountRepository.save(account);

        String token = jwtService.generateToken(saved.getEmail(), saved.getDomainRole(), saved.getAccountId());

        return AuthResponseDto.builder()
                .token(token)
                .accountId(saved.getAccountId())
                .fullName(saved.getFullName())
                .domainRole(saved.getDomainRole())
                .email(saved.getEmail())
                .build();
    }

    public AuthResponseDto authenticate(AuthRequestDto dto) {
        CampaignAccount account = campaignAccountRepository.findByEmail(dto.getEmail())
                .orElseThrow(() -> new BadCredentialsException("Invalid email or password"));

        if (!account.isActive()) {
            throw new BadCredentialsException("Account is inactive");
        }

        if (!passwordEncoder.matches(dto.getPassword(), account.getPasswordHash())) {
            throw new BadCredentialsException("Invalid email or password");
        }

        String token = jwtService.generateToken(account.getEmail(), account.getDomainRole(), account.getAccountId());
        String refreshToken = jwtService.generateToken(account.getEmail(), account.getDomainRole(), account.getAccountId());

        return AuthResponseDto.builder()
                .token(token)
                .refreshToken(refreshToken)
                .accountId(account.getAccountId())
                .fullName(account.getFullName())
                .domainRole(account.getDomainRole())
                .email(account.getEmail())
                .build();
    }
}
