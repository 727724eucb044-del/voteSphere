package com.example.demo.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Entity
@Table(name = "outreach_events")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OutreachEvent {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long eventId;

    @Column(name = "event_title", nullable = false, length = 150)
    private String eventTitle;

    @Enumerated(EnumType.STRING)
    @Column(name = "event_type", nullable = false)
    private EventType eventType;

    @Column(nullable = false, length = 200)
    private String location;

    @Column(name = "scheduled_date", nullable = false)
    private LocalDateTime scheduledDate;

    @Column(name = "target_capacity", nullable = false)
    private Integer targetCapacity;

    @Builder.Default
    @Column(name = "current_registrations")
    private Integer currentRegistrations = 0;

    @Enumerated(EnumType.STRING)
    @Column(name = "event_status", nullable = false)
    private EventStatus eventStatus;

    public enum EventType {
        RALLY, PHONE_BANK, TOWN_HALL, DOOR_TO_DOOR
    }

    public enum EventStatus {
        PLANNED, ACTIVE, COMPLETED, CANCELLED
    }
}
