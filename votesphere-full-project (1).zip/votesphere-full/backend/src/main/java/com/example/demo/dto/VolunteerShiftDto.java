package com.example.demo.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class VolunteerShiftDto {
    private Long shiftId;
    private Long eventId;
    private Long assignedVolunteerId;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private String shiftStatus;
}
