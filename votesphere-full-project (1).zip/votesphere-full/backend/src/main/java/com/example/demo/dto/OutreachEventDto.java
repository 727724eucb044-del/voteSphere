package com.example.demo.dto;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OutreachEventDto {

    private Long eventId;

    @NotNull(message = "Event title is mandatory")
    @Size(min = 2, max = 150)
    private String eventTitle;

    @NotNull(message = "Event type is mandatory")
    private String eventType;

    @NotNull(message = "Location is mandatory")
    private String location;

    @NotNull(message = "Scheduled date is mandatory")
    private LocalDateTime scheduledDate;

    @NotNull
    private Integer targetCapacity;

    private Integer currentRegistrations;

    private String eventStatus;
}
