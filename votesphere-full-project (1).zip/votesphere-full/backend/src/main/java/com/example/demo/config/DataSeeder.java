package com.example.demo.config;

import com.example.demo.entity.CampaignAccount;
import com.example.demo.repository.CampaignAccountRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
public class DataSeeder implements CommandLineRunner {

    private final CampaignAccountRepository campaignAccountRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) {
        if (campaignAccountRepository.count() == 0) {
            CampaignAccount director = CampaignAccount.builder()
                    .email("director@votesphere.org")
                    .passwordHash(passwordEncoder.encode("password123"))
                    .fullName("Marcus Cole")
                    .domainRole(CampaignAccount.Role.CAMPAIGN_DIRECTOR.name())
                    .phoneNumber("+1-555-0100")
                    .isActive(true)
                    .build();
            campaignAccountRepository.save(director);
        }
    }
}
