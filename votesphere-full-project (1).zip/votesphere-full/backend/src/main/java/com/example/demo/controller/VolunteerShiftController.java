package com.example.demo.controller;

import com.example.demo.dto.VolunteerShiftDto;
import com.example.demo.service.VolunteerOperationsService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/shifts")
@RequiredArgsConstructor
public class VolunteerShiftController {

    private final VolunteerOperationsService volunteerOperationsService;

    @GetMapping
    public ResponseEntity<List<VolunteerShiftDto>> getAllShifts() {
        return ResponseEntity.ok(volunteerOperationsService.getAllShifts());
    }

    @PostMapping
    @PreAuthorize("hasAnyAuthority('CAMPAIGN_DIRECTOR', 'FIELD_ORGANIZER')")
    public ResponseEntity<VolunteerShiftDto> createShift(@RequestBody VolunteerShiftDto dto) {
        VolunteerShiftDto created = volunteerOperationsService.createShift(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(created);
    }

    @PostMapping("/{shiftId}/reserve")
    @PreAuthorize("hasAuthority('OUTREACH_VOLUNTEER')")
    public ResponseEntity<VolunteerShiftDto> reserveShift(@PathVariable Long shiftId, @RequestParam Long accountId) {
        return ResponseEntity.ok(volunteerOperationsService.reserveShiftSlot(shiftId, accountId));
    }

    @PutMapping("/{id}/status")
    @PreAuthorize("hasAnyAuthority('CAMPAIGN_DIRECTOR', 'FIELD_ORGANIZER')")
    public ResponseEntity<VolunteerShiftDto> updateShiftStatus(@PathVariable Long id, @RequestParam String status) {
        return ResponseEntity.ok(volunteerOperationsService.updateShiftStatus(id, status));
    }

    @GetMapping("/my-schedule")
    @PreAuthorize("hasAuthority('OUTREACH_VOLUNTEER')")
    public ResponseEntity<List<VolunteerShiftDto>> mySchedule(@RequestParam Long accountId) {
        return ResponseEntity.ok(volunteerOperationsService.getMySchedule(accountId));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAuthority('CAMPAIGN_DIRECTOR')")
    public ResponseEntity<String> deleteShift(@PathVariable Long id) {
        volunteerOperationsService.deleteShift(id);
        return ResponseEntity.ok("VolunteerShift deleted successfully.");
    }
}
