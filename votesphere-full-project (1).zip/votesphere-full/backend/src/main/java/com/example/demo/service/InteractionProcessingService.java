package com.example.demo.service;

import com.example.demo.dto.VoterInteractionDto;
import com.example.demo.entity.CampaignAccount;
import com.example.demo.entity.VoterInteraction;
import com.example.demo.entity.VoterProfile;
import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repository.CampaignAccountRepository;
import com.example.demo.repository.VoterInteractionRepository;
import com.example.demo.repository.VoterProfileRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class InteractionProcessingService {

    private final VoterInteractionRepository voterInteractionRepository;
    private final VoterProfileRepository voterProfileRepository;
    private final CampaignAccountRepository campaignAccountRepository;
    private final VoterEngagementService voterEngagementService;

    /**
     * Persists a detailed log of field engagement including the interaction channel
     * and detected sentiment. Automatically triggers the support score recalculation
     * for the linked voter profile.
     */
    @Transactional
    public VoterInteractionDto logInteractionSession(VoterInteractionDto dto) {
        VoterProfile voter = voterProfileRepository.findById(dto.getVoterId())
                .orElseThrow(() -> new ResourceNotFoundException("VoterProfile not found with id: " + dto.getVoterId()));

        CampaignAccount volunteer = campaignAccountRepository.findById(dto.getVolunteerId())
                .orElseThrow(() -> new ResourceNotFoundException("CampaignAccount not found with id: " + dto.getVolunteerId()));

        VoterInteraction interaction = VoterInteraction.builder()
                .voter(voter)
                .volunteer(volunteer)
                .interactionChannel(VoterInteraction.InteractionChannel.valueOf(dto.getInteractionChannel()))
                .sentimentDetected(dto.getSentimentDetected() != null
                        ? VoterInteraction.Sentiment.valueOf(dto.getSentimentDetected()) : null)
                .policyIssueTag(dto.getPolicyIssueTag())
                .interactionNotes(dto.getInteractionNotes())
                .build();

        VoterInteraction saved = voterInteractionRepository.save(interaction);

        voter.setLastContactedDate(LocalDateTime.now());
        voterProfileRepository.save(voter);

        voterEngagementService.updateVoterStatusLifecycle(voter.getVoterId());

        return toDto(saved);
    }

    public List<VoterInteractionDto> getAllInteractions() {
        return voterInteractionRepository.findAll().stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    /**
     * Provides data for the real-time engagement feed.
     */
    public List<VoterInteractionDto> getRecentFeed() {
        return voterInteractionRepository.findRecentInteractions().stream()
                .map(this::toDto)
                .collect(Collectors.toList());
    }

    private VoterInteractionDto toDto(VoterInteraction interaction) {
        return VoterInteractionDto.builder()
                .interactionId(interaction.getInteractionId())
                .voterId(interaction.getVoter() != null ? interaction.getVoter().getVoterId() : null)
                .volunteerId(interaction.getVolunteer() != null ? interaction.getVolunteer().getAccountId() : null)
                .interactionChannel(interaction.getInteractionChannel() != null ? interaction.getInteractionChannel().name() : null)
                .sentimentDetected(interaction.getSentimentDetected() != null ? interaction.getSentimentDetected().name() : null)
                .policyIssueTag(interaction.getPolicyIssueTag())
                .interactionNotes(interaction.getInteractionNotes())
                .build();
    }
}
